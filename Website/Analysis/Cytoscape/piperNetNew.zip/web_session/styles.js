var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.9.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-width" : 0.0,
      "text-opacity" : 1.0,
      "height" : 35.0,
      "font-size" : 30,
      "border-opacity" : 1.0,
      "width" : 35.0,
      "background-color" : "rgb(137,208,245)",
      "background-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "Calisto MT Bold",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "text-valign" : "center",
      "text-halign" : "center",
      "border-color" : "rgb(204,204,204)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[Target_Des = 'keyword']",
    "css" : {
      "shape" : "diamond"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "color" : "rgb(0,0,0)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "line-color" : "rgb(132,132,132)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "line-style" : "solid",
      "font-size" : 100
    }
  }, {
    "selector" : "edge[Keyword_Count > 11]",
    "css" : {
      "line-color" : "rgb(68,1,84)"
    }
  }, {
    "selector" : "edge[Keyword_Count = 11]",
    "css" : {
      "line-color" : "rgb(68,2,86)"
    }
  }, {
    "selector" : "edge[Keyword_Count > 6][Keyword_Count < 11]",
    "css" : {
      "line-color" : "mapData(Keyword_Count,6,11,rgb(33,145,140),rgb(68,2,86))"
    }
  }, {
    "selector" : "edge[Keyword_Count > 1][Keyword_Count < 6]",
    "css" : {
      "line-color" : "mapData(Keyword_Count,1,6,rgb(247,104,161),rgb(33,145,140))"
    }
  }, {
    "selector" : "edge[Keyword_Count = 1]",
    "css" : {
      "line-color" : "rgb(247,104,161)"
    }
  }, {
    "selector" : "edge[Keyword_Count < 1]",
    "css" : {
      "line-color" : "rgb(253,231,37)"
    }
  }, {
    "selector" : "edge[Keyword_Count > 11]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[Keyword_Count = 11]",
    "css" : {
      "width" : 11.2346021140494
    }
  }, {
    "selector" : "edge[Keyword_Count > 1][Keyword_Count < 11]",
    "css" : {
      "width" : "mapData(Keyword_Count,1,11,4.932264281482231,11.2346021140494)"
    }
  }, {
    "selector" : "edge[Keyword_Count = 1]",
    "css" : {
      "width" : 4.932264281482231
    }
  }, {
    "selector" : "edge[Keyword_Count < 1]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]