var networks = {"piperNet.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.9.0",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "piperNet.tsv",
    "name" : "piperNet.tsv",
    "SUID" : 151,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "1952",
        "ClosenessCentrality" : 0.29260450160771706,
        "Eccentricity" : 5,
        "Degree" : 13,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9267399267399268,
        "Stress" : 156,
        "TopologicalCoefficient" : 1.0,
        "shared_name" : "weather",
        "BetweennessCentrality" : 0.0027210884353741495,
        "NumberOfUndirectedEdges" : 13,
        "name" : "weather",
        "SelfLoops" : 0,
        "SUID" : 1952,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4175824175824174,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -290.6992537016983,
        "y" : -263.7144308559854
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1898",
        "ClosenessCentrality" : 0.41363636363636364,
        "Eccentricity" : 4,
        "Degree" : 17,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.125,
        "Radiality" : 0.957042957042957,
        "Stress" : 10386,
        "TopologicalCoefficient" : 0.2777777777777778,
        "shared_name" : "toxicity",
        "BetweennessCentrality" : 0.014526020833527106,
        "NumberOfUndirectedEdges" : 17,
        "name" : "toxicity",
        "SelfLoops" : 0,
        "SUID" : 1898,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.4175824175824174,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.5
      },
      "position" : {
        "x" : 136.92588723224145,
        "y" : 73.70624357721081
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1868",
        "ClosenessCentrality" : 0.40625,
        "Eccentricity" : 4,
        "Degree" : 9,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.07142857142857142,
        "Radiality" : 0.9557109557109558,
        "Stress" : 4250,
        "TopologicalCoefficient" : 0.375,
        "shared_name" : "time",
        "BetweennessCentrality" : 0.009517206098631754,
        "NumberOfUndirectedEdges" : 9,
        "name" : "time",
        "SelfLoops" : 0,
        "SUID" : 1868,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.4615384615384617,
        "selected" : false,
        "NeighborhoodConnectivity" : 15.25
      },
      "position" : {
        "x" : -118.03085410076636,
        "y" : 146.7576351787733
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1826",
        "ClosenessCentrality" : 0.29260450160771706,
        "Eccentricity" : 5,
        "Degree" : 13,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9267399267399268,
        "Stress" : 156,
        "TopologicalCoefficient" : 1.0,
        "shared_name" : "tension",
        "BetweennessCentrality" : 0.0027210884353741495,
        "NumberOfUndirectedEdges" : 13,
        "name" : "tension",
        "SelfLoops" : 0,
        "SUID" : 1826,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4175824175824174,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -593.1081490030094,
        "y" : -245.3358077397892
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1796",
        "ClosenessCentrality" : 0.3872340425531915,
        "Eccentricity" : 4,
        "Degree" : 9,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.952047952047952,
        "Stress" : 424,
        "TopologicalCoefficient" : 0.2950191570881226,
        "shared_name" : "stalking",
        "BetweennessCentrality" : 0.0031922693742542324,
        "NumberOfUndirectedEdges" : 9,
        "name" : "stalking",
        "SelfLoops" : 0,
        "SUID" : 1796,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5824175824175826,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.555555555555555
      },
      "position" : {
        "x" : 59.41734231036645,
        "y" : -201.20249360540637
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1766",
        "ClosenessCentrality" : 0.39224137931034486,
        "Eccentricity" : 4,
        "Degree" : 9,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9530469530469531,
        "Stress" : 5552,
        "TopologicalCoefficient" : 0.3942652329749104,
        "shared_name" : "self-harm",
        "BetweennessCentrality" : 0.00532059926606905,
        "NumberOfUndirectedEdges" : 9,
        "name" : "self-harm",
        "SelfLoops" : 0,
        "SUID" : 1766,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5494505494505493,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.222222222222221
      },
      "position" : {
        "x" : -338.6268404932708,
        "y" : 307.9190554830388
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1700",
        "ClosenessCentrality" : 0.45728643216080406,
        "Eccentricity" : 4,
        "Degree" : 21,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.047619047619047616,
        "Radiality" : 0.964035964035964,
        "Stress" : 35276,
        "TopologicalCoefficient" : 0.232016210739615,
        "shared_name" : "sadness",
        "BetweennessCentrality" : 0.06532864468916734,
        "NumberOfUndirectedEdges" : 21,
        "name" : "sadness",
        "SelfLoops" : 0,
        "SUID" : 1700,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1868131868131866,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.333333333333334
      },
      "position" : {
        "x" : 90.68894875567895,
        "y" : -8.617321905882449
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1670",
        "ClosenessCentrality" : 0.3714285714285714,
        "Eccentricity" : 4,
        "Degree" : 9,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.2222222222222222,
        "Radiality" : 0.9487179487179487,
        "Stress" : 2072,
        "TopologicalCoefficient" : 0.3501683501683502,
        "shared_name" : "romance",
        "BetweennessCentrality" : 0.002957917076098186,
        "NumberOfUndirectedEdges" : 9,
        "name" : "romance",
        "SelfLoops" : 0,
        "SUID" : 1670,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6923076923076925,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.555555555555555
      },
      "position" : {
        "x" : 295.0990744881008,
        "y" : 87.82096678277722
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1616",
        "ClosenessCentrality" : 0.41363636363636364,
        "Eccentricity" : 4,
        "Degree" : 17,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.125,
        "Radiality" : 0.957042957042957,
        "Stress" : 10386,
        "TopologicalCoefficient" : 0.2777777777777778,
        "shared_name" : "relationship",
        "BetweennessCentrality" : 0.014526020833527106,
        "NumberOfUndirectedEdges" : 17,
        "name" : "relationship",
        "SelfLoops" : 0,
        "SUID" : 1616,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.4175824175824174,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.5
      },
      "position" : {
        "x" : 263.1906272224758,
        "y" : 81.09757048150769
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1550",
        "ClosenessCentrality" : 0.29260450160771706,
        "Eccentricity" : 5,
        "Degree" : 13,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9267399267399268,
        "Stress" : 156,
        "TopologicalCoefficient" : 1.0,
        "shared_name" : "rain",
        "BetweennessCentrality" : 0.0027210884353741495,
        "NumberOfUndirectedEdges" : 13,
        "name" : "rain",
        "SelfLoops" : 0,
        "SUID" : 1550,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4175824175824174,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -612.3285670851648,
        "y" : -37.09958651939532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1526",
        "ClosenessCentrality" : 0.3991228070175439,
        "Eccentricity" : 4,
        "Degree" : 7,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9543789543789545,
        "Stress" : 520,
        "TopologicalCoefficient" : 0.3306122448979592,
        "shared_name" : "parasite",
        "BetweennessCentrality" : 0.0023992018345375325,
        "NumberOfUndirectedEdges" : 7,
        "name" : "parasite",
        "SelfLoops" : 0,
        "SUID" : 1526,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5054945054945055,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.571428571428571
      },
      "position" : {
        "x" : -480.0684713873064,
        "y" : 220.64935766582272
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1436",
        "ClosenessCentrality" : 0.5055555555555555,
        "Eccentricity" : 4,
        "Degree" : 29,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9703629703629704,
        "Stress" : 62798,
        "TopologicalCoefficient" : 0.19454887218045114,
        "shared_name" : "paranoia",
        "BetweennessCentrality" : 0.07516566482063113,
        "NumberOfUndirectedEdges" : 29,
        "name" : "paranoia",
        "SelfLoops" : 0,
        "SUID" : 1436,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.978021978021978,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.392857142857142
      },
      "position" : {
        "x" : -369.23607293262137,
        "y" : -12.623020915142835
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1298",
        "ClosenessCentrality" : 0.5083798882681565,
        "Eccentricity" : 4,
        "Degree" : 36,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 0.01935483870967742,
        "Radiality" : 0.9706959706959708,
        "Stress" : 81162,
        "TopologicalCoefficient" : 0.21669004207573633,
        "shared_name" : "mental-illness",
        "BetweennessCentrality" : 0.14185217213374746,
        "NumberOfUndirectedEdges" : 36,
        "name" : "mental-illness",
        "SelfLoops" : 0,
        "SUID" : 1298,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.967032967032967,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.612903225806452
      },
      "position" : {
        "x" : 81.29991066974145,
        "y" : 39.98488050958386
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1244",
        "ClosenessCentrality" : 0.41363636363636364,
        "Eccentricity" : 4,
        "Degree" : 17,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.125,
        "Radiality" : 0.957042957042957,
        "Stress" : 10386,
        "TopologicalCoefficient" : 0.2777777777777778,
        "shared_name" : "love",
        "BetweennessCentrality" : 0.014526020833527106,
        "NumberOfUndirectedEdges" : 17,
        "name" : "love",
        "SelfLoops" : 0,
        "SUID" : 1244,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.4175824175824174,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.5
      },
      "position" : {
        "x" : 178.16746438067895,
        "y" : -33.42861932256946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1208",
        "ClosenessCentrality" : 0.4155251141552512,
        "Eccentricity" : 4,
        "Degree" : 11,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.16363636363636364,
        "Radiality" : 0.9573759573759574,
        "Stress" : 9834,
        "TopologicalCoefficient" : 0.3359683794466403,
        "shared_name" : "loss",
        "BetweennessCentrality" : 0.015401021427402973,
        "NumberOfUndirectedEdges" : 11,
        "name" : "loss",
        "SelfLoops" : 0,
        "SUID" : 1208,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.4065934065934065,
        "selected" : false,
        "NeighborhoodConnectivity" : 15.454545454545455
      },
      "position" : {
        "x" : 133.90025246661645,
        "y" : 34.54723936578503
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1166",
        "ClosenessCentrality" : 0.4232558139534884,
        "Eccentricity" : 4,
        "Degree" : 13,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.015151515151515152,
        "Radiality" : 0.9587079587079588,
        "Stress" : 5394,
        "TopologicalCoefficient" : 0.29914529914529914,
        "shared_name" : "isolation",
        "BetweennessCentrality" : 0.015473453816009885,
        "NumberOfUndirectedEdges" : 13,
        "name" : "isolation",
        "SelfLoops" : 0,
        "SUID" : 1166,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.3626373626373627,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.5
      },
      "position" : {
        "x" : -129.98312460857886,
        "y" : 7.3396320964979225
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1154",
        "ClosenessCentrality" : 0.34210526315789475,
        "Eccentricity" : 4,
        "Degree" : 3,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.9417249417249417,
        "Stress" : 10,
        "TopologicalCoefficient" : 0.7272727272727273,
        "shared_name" : "injury",
        "BetweennessCentrality" : 4.889290603576317E-5,
        "NumberOfUndirectedEdges" : 3,
        "name" : "injury",
        "SelfLoops" : 0,
        "SUID" : 1154,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.923076923076923,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : -114.35406577068824,
        "y" : 190.5469113018202
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1130",
        "ClosenessCentrality" : 0.3991228070175439,
        "Eccentricity" : 4,
        "Degree" : 7,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9543789543789545,
        "Stress" : 520,
        "TopologicalCoefficient" : 0.3306122448979592,
        "shared_name" : "imposter-syndrome",
        "BetweennessCentrality" : 0.0023992018345375325,
        "NumberOfUndirectedEdges" : 7,
        "name" : "imposter-syndrome",
        "SelfLoops" : 0,
        "SUID" : 1130,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5054945054945055,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.571428571428571
      },
      "position" : {
        "x" : 25.133742456850825,
        "y" : -45.059169707090945
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1070",
        "ClosenessCentrality" : 0.4690721649484536,
        "Eccentricity" : 3,
        "Degree" : 19,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9657009657009658,
        "Stress" : 48492,
        "TopologicalCoefficient" : 0.21052631578947367,
        "shared_name" : "imagery",
        "BetweennessCentrality" : 0.06815889767836718,
        "NumberOfUndirectedEdges" : 19,
        "name" : "imagery",
        "SelfLoops" : 0,
        "SUID" : 1070,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.131868131868132,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.631578947368421
      },
      "position" : {
        "x" : -170.4343575187351,
        "y" : -49.29777329900989
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "983",
        "ClosenessCentrality" : 0.47150259067357514,
        "Eccentricity" : 4,
        "Degree" : 28,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 0.036231884057971016,
        "Radiality" : 0.9660339660339661,
        "Stress" : 48206,
        "TopologicalCoefficient" : 0.22872340425531915,
        "shared_name" : "illness",
        "BetweennessCentrality" : 0.08341460070771829,
        "NumberOfUndirectedEdges" : 28,
        "name" : "illness",
        "SelfLoops" : 0,
        "SUID" : 983,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.120879120879121,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.25
      },
      "position" : {
        "x" : 128.99888527911645,
        "y" : 53.65666014215222
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "953",
        "ClosenessCentrality" : 0.39224137931034486,
        "Eccentricity" : 4,
        "Degree" : 9,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9530469530469531,
        "Stress" : 5552,
        "TopologicalCoefficient" : 0.3942652329749104,
        "shared_name" : "hunger",
        "BetweennessCentrality" : 0.00532059926606905,
        "NumberOfUndirectedEdges" : 9,
        "name" : "hunger",
        "SelfLoops" : 0,
        "SUID" : 953,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5494505494505493,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.222222222222221
      },
      "position" : {
        "x" : 171.11631691974145,
        "y" : 245.05689054986706
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "932",
        "ClosenessCentrality" : 0.34210526315789475,
        "Eccentricity" : 4,
        "Degree" : 3,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.9417249417249417,
        "Stress" : 10,
        "TopologicalCoefficient" : 0.7272727272727273,
        "shared_name" : "heart",
        "BetweennessCentrality" : 4.889290603576317E-5,
        "NumberOfUndirectedEdges" : 3,
        "name" : "heart",
        "SelfLoops" : 0,
        "SUID" : 932,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.923076923076923,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : -112.05362021404761,
        "y" : 235.0100460674452
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "920",
        "ClosenessCentrality" : 0.34210526315789475,
        "Eccentricity" : 4,
        "Degree" : 3,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.9417249417249417,
        "Stress" : 10,
        "TopologicalCoefficient" : 0.7272727272727273,
        "shared_name" : "health",
        "BetweennessCentrality" : 4.889290603576317E-5,
        "NumberOfUndirectedEdges" : 3,
        "name" : "health",
        "SelfLoops" : 0,
        "SUID" : 920,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.923076923076923,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : -157.86895834881324,
        "y" : 206.2748470928358
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "908",
        "ClosenessCentrality" : 0.34210526315789475,
        "Eccentricity" : 4,
        "Degree" : 3,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.9417249417249417,
        "Stress" : 10,
        "TopologicalCoefficient" : 0.7272727272727273,
        "shared_name" : "grief",
        "BetweennessCentrality" : 4.889290603576317E-5,
        "NumberOfUndirectedEdges" : 3,
        "name" : "grief",
        "SelfLoops" : 0,
        "SUID" : 908,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.923076923076923,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : -173.99272238689917,
        "y" : 159.765127244203
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "800",
        "ClosenessCentrality" : 0.5449101796407186,
        "Eccentricity" : 3,
        "Degree" : 35,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.001893939393939394,
        "Radiality" : 0.9746919746919748,
        "Stress" : 97460,
        "TopologicalCoefficient" : 0.1919191919191919,
        "shared_name" : "fear",
        "BetweennessCentrality" : 0.14528111059728963,
        "NumberOfUndirectedEdges" : 35,
        "name" : "fear",
        "SelfLoops" : 0,
        "SUID" : 800,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.835164835164835,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 136.20592649136307,
        "y" : -182.57139773331565
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "770",
        "ClosenessCentrality" : 0.3872340425531915,
        "Eccentricity" : 4,
        "Degree" : 9,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.952047952047952,
        "Stress" : 424,
        "TopologicalCoefficient" : 0.2950191570881226,
        "shared_name" : "eyes",
        "BetweennessCentrality" : 0.0031922693742542324,
        "NumberOfUndirectedEdges" : 9,
        "name" : "eyes",
        "SelfLoops" : 0,
        "SUID" : 770,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5824175824175826,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.555555555555555
      },
      "position" : {
        "x" : 79.22947609942895,
        "y" : -95.95624726751575
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "740",
        "ClosenessCentrality" : 0.39224137931034486,
        "Eccentricity" : 4,
        "Degree" : 9,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9530469530469531,
        "Stress" : 5552,
        "TopologicalCoefficient" : 0.3942652329749104,
        "shared_name" : "empty",
        "BetweennessCentrality" : 0.00532059926606905,
        "NumberOfUndirectedEdges" : 9,
        "name" : "empty",
        "SelfLoops" : 0,
        "SUID" : 740,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5494505494505493,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.222222222222221
      },
      "position" : {
        "x" : 51.020888452944575,
        "y" : 181.3284054424452
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "710",
        "ClosenessCentrality" : 0.39224137931034486,
        "Eccentricity" : 4,
        "Degree" : 9,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9530469530469531,
        "Stress" : 5552,
        "TopologicalCoefficient" : 0.3942652329749104,
        "shared_name" : "eating-disorder",
        "BetweennessCentrality" : 0.00532059926606905,
        "NumberOfUndirectedEdges" : 9,
        "name" : "eating-disorder",
        "SelfLoops" : 0,
        "SUID" : 710,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5494505494505493,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.222222222222221
      },
      "position" : {
        "x" : 449.631551255139,
        "y" : 194.36958499619044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "671",
        "ClosenessCentrality" : 0.4212962962962963,
        "Eccentricity" : 4,
        "Degree" : 12,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.030303030303030304,
        "Radiality" : 0.9583749583749585,
        "Stress" : 12664,
        "TopologicalCoefficient" : 0.33760683760683763,
        "shared_name" : "depression",
        "BetweennessCentrality" : 0.016191644235359064,
        "NumberOfUndirectedEdges" : 12,
        "name" : "depression",
        "SelfLoops" : 0,
        "SUID" : 671,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.3736263736263736,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.916666666666666
      },
      "position" : {
        "x" : -501.9851945404892,
        "y" : 120.32459890091431
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "662",
        "ClosenessCentrality" : 0.4375,
        "Eccentricity" : 4,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.16666666666666666,
        "Radiality" : 0.961038961038961,
        "Stress" : 6582,
        "TopologicalCoefficient" : 0.20833333333333334,
        "countKeyword" : 11,
        "shared_name" : "Heartbeat",
        "BetweennessCentrality" : 0.02282206491609198,
        "NumberOfUndirectedEdges" : 12,
        "ck_label" : "countKeyword",
        "name" : "Heartbeat",
        "SelfLoops" : 0,
        "SUID" : 662,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2857142857142856,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.666666666666666
      },
      "position" : {
        "x" : 166.42140953077507,
        "y" : 368.2968526123473
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "656",
        "ClosenessCentrality" : 0.34210526315789475,
        "Eccentricity" : 4,
        "Degree" : 3,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.9417249417249417,
        "Stress" : 10,
        "TopologicalCoefficient" : 0.7272727272727273,
        "shared_name" : "death",
        "BetweennessCentrality" : 4.889290603576317E-5,
        "NumberOfUndirectedEdges" : 3,
        "name" : "death",
        "SelfLoops" : 0,
        "SUID" : 656,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.923076923076923,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : -72.80430685955542,
        "y" : 244.12094694635144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "629",
        "ClosenessCentrality" : 0.3872340425531915,
        "Eccentricity" : 4,
        "Degree" : 8,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.25,
        "Radiality" : 0.952047952047952,
        "Stress" : 3898,
        "TopologicalCoefficient" : 0.40131578947368424,
        "shared_name" : "color",
        "BetweennessCentrality" : 0.003400663653408087,
        "NumberOfUndirectedEdges" : 8,
        "name" : "color",
        "SelfLoops" : 0,
        "SUID" : 629,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5824175824175826,
        "selected" : false,
        "NeighborhoodConnectivity" : 15.25
      },
      "position" : {
        "x" : 129.93189919513208,
        "y" : -141.81401246526966
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "608",
        "ClosenessCentrality" : 0.4026548672566372,
        "Eccentricity" : 4,
        "Degree" : 6,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9550449550449551,
        "Stress" : 2836,
        "TopologicalCoefficient" : 0.37719298245614036,
        "shared_name" : "clock",
        "BetweennessCentrality" : 0.005644895744923629,
        "NumberOfUndirectedEdges" : 6,
        "name" : "clock",
        "SelfLoops" : 0,
        "SUID" : 608,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.4835164835164836,
        "selected" : false,
        "NeighborhoodConnectivity" : 15.333333333333334
      },
      "position" : {
        "x" : -112.18063437420386,
        "y" : 99.31473356744519
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "581",
        "ClosenessCentrality" : 0.3872340425531915,
        "Eccentricity" : 4,
        "Degree" : 8,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.25,
        "Radiality" : 0.952047952047952,
        "Stress" : 3898,
        "TopologicalCoefficient" : 0.40131578947368424,
        "shared_name" : "betrayal",
        "BetweennessCentrality" : 0.003400663653408087,
        "NumberOfUndirectedEdges" : 8,
        "name" : "betrayal",
        "SelfLoops" : 0,
        "SUID" : 581,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5824175824175826,
        "selected" : false,
        "NeighborhoodConnectivity" : 15.25
      },
      "position" : {
        "x" : 95.4722129158352,
        "y" : -116.43874543646106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "575",
        "ClosenessCentrality" : 0.3714285714285714,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9487179487179487,
        "Stress" : 14776,
        "TopologicalCoefficient" : 0.625,
        "countKeyword" : 1,
        "shared_name" : "rain drop",
        "BetweennessCentrality" : 0.004647974855833255,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "rain drop",
        "SelfLoops" : 0,
        "SUID" : 575,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6923076923076925,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : 3.403428000693051,
        "y" : -278.73172860581366
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "569",
        "ClosenessCentrality" : 0.3714285714285714,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9487179487179487,
        "Stress" : 14776,
        "TopologicalCoefficient" : 0.625,
        "countKeyword" : 1,
        "shared_name" : "quiet",
        "BetweennessCentrality" : 0.004647974855833255,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "quiet",
        "SelfLoops" : 0,
        "SUID" : 569,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6923076923076925,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -238.9854057975437,
        "y" : -118.00551026800403
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "563",
        "ClosenessCentrality" : 0.3714285714285714,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9487179487179487,
        "Stress" : 14776,
        "TopologicalCoefficient" : 0.625,
        "countKeyword" : 1,
        "shared_name" : "flurry",
        "BetweennessCentrality" : 0.004647974855833255,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "flurry",
        "SelfLoops" : 0,
        "SUID" : 563,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6923076923076925,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -262.12744605022925,
        "y" : -77.39829057195911
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "557",
        "ClosenessCentrality" : 0.3714285714285714,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9487179487179487,
        "Stress" : 14776,
        "TopologicalCoefficient" : 0.625,
        "countKeyword" : 1,
        "shared_name" : "frigid",
        "BetweennessCentrality" : 0.004647974855833255,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "frigid",
        "SelfLoops" : 0,
        "SUID" : 557,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6923076923076925,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -121.48719870525855,
        "y" : -193.20771211126575
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "551",
        "ClosenessCentrality" : 0.3714285714285714,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9487179487179487,
        "Stress" : 14776,
        "TopologicalCoefficient" : 0.625,
        "countKeyword" : 1,
        "shared_name" : "chill",
        "BetweennessCentrality" : 0.004647974855833255,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "chill",
        "SelfLoops" : 0,
        "SUID" : 551,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6923076923076925,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -247.65924155193824,
        "y" : -140.06345551946887
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "ClosenessCentrality" : 0.3714285714285714,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9487179487179487,
        "Stress" : 14776,
        "TopologicalCoefficient" : 0.625,
        "countKeyword" : 1,
        "shared_name" : "Howling",
        "BetweennessCentrality" : 0.004647974855833255,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "Howling",
        "SelfLoops" : 0,
        "SUID" : 545,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6923076923076925,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -182.1781777091648,
        "y" : -224.4623660419298
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "539",
        "ClosenessCentrality" : 0.3714285714285714,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9487179487179487,
        "Stress" : 14776,
        "TopologicalCoefficient" : 0.625,
        "countKeyword" : 1,
        "shared_name" : "gale",
        "BetweennessCentrality" : 0.004647974855833255,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "gale",
        "SelfLoops" : 0,
        "SUID" : 539,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6923076923076925,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -225.94991385418433,
        "y" : -94.96886628607044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "ClosenessCentrality" : 0.3714285714285714,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9487179487179487,
        "Stress" : 14776,
        "TopologicalCoefficient" : 0.625,
        "countKeyword" : 1,
        "shared_name" : "thunder",
        "BetweennessCentrality" : 0.004647974855833255,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "thunder",
        "SelfLoops" : 0,
        "SUID" : 533,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6923076923076925,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -160.4993447013523,
        "y" : -184.66503327825794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "527",
        "ClosenessCentrality" : 0.3714285714285714,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9487179487179487,
        "Stress" : 14776,
        "TopologicalCoefficient" : 0.625,
        "countKeyword" : 1,
        "shared_name" : "raining",
        "BetweennessCentrality" : 0.004647974855833255,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "raining",
        "SelfLoops" : 0,
        "SUID" : 527,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6923076923076925,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -193.8362587638523,
        "y" : -184.5499820087267
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "521",
        "ClosenessCentrality" : 0.3714285714285714,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9487179487179487,
        "Stress" : 14776,
        "TopologicalCoefficient" : 0.625,
        "countKeyword" : 1,
        "shared_name" : "frightening",
        "BetweennessCentrality" : 0.004647974855833255,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "frightening",
        "SelfLoops" : 0,
        "SUID" : 521,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6923076923076925,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -131.5594490714695,
        "y" : -227.83161347845325
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "515",
        "ClosenessCentrality" : 0.3714285714285714,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9487179487179487,
        "Stress" : 14776,
        "TopologicalCoefficient" : 0.625,
        "countKeyword" : 1,
        "shared_name" : "grey sky",
        "BetweennessCentrality" : 0.004647974855833255,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "grey sky",
        "SelfLoops" : 0,
        "SUID" : 515,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6923076923076925,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -203.33504569012183,
        "y" : -149.45205110052356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "509",
        "ClosenessCentrality" : 0.3714285714285714,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9487179487179487,
        "Stress" : 14776,
        "TopologicalCoefficient" : 0.625,
        "countKeyword" : 1,
        "shared_name" : "clouds",
        "BetweennessCentrality" : 0.004647974855833255,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "clouds",
        "SelfLoops" : 0,
        "SUID" : 509,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6923076923076925,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -275.8125466056492,
        "y" : -106.1671237323595
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "503",
        "ClosenessCentrality" : 0.3714285714285714,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9487179487179487,
        "Stress" : 14776,
        "TopologicalCoefficient" : 0.625,
        "countKeyword" : 1,
        "shared_name" : "air",
        "BetweennessCentrality" : 0.004647974855833255,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "air",
        "SelfLoops" : 0,
        "SUID" : 503,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6923076923076925,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -192.71090781170386,
        "y" : -121.46470063665637
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "497",
        "ClosenessCentrality" : 0.441747572815534,
        "Eccentricity" : 3,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9617049617049618,
        "Stress" : 8088,
        "TopologicalCoefficient" : 0.40970350404312667,
        "countKeyword" : 1,
        "shared_name" : "Witnessed.",
        "BetweennessCentrality" : 0.006162950178061703,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "Witnessed.",
        "SelfLoops" : 0,
        "SUID" : 497,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2637362637362637,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.714285714285715
      },
      "position" : {
        "x" : 222.71228390873912,
        "y" : -304.59077861357713
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "491",
        "ClosenessCentrality" : 0.441747572815534,
        "Eccentricity" : 3,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9617049617049618,
        "Stress" : 8088,
        "TopologicalCoefficient" : 0.40970350404312667,
        "countKeyword" : 1,
        "shared_name" : "Never",
        "BetweennessCentrality" : 0.006162950178061703,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "Never",
        "SelfLoops" : 0,
        "SUID" : 491,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2637362637362637,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.714285714285715
      },
      "position" : {
        "x" : 0.5391074470852004,
        "y" : -82.77175324896106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "ClosenessCentrality" : 0.441747572815534,
        "Eccentricity" : 3,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9617049617049618,
        "Stress" : 8088,
        "TopologicalCoefficient" : 0.40970350404312667,
        "countKeyword" : 1,
        "shared_name" : "They see it",
        "BetweennessCentrality" : 0.006162950178061703,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "They see it",
        "SelfLoops" : 0,
        "SUID" : 485,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2637362637362637,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.714285714285715
      },
      "position" : {
        "x" : -2.4103554435397996,
        "y" : -122.72902863958606
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "479",
        "ClosenessCentrality" : 0.441747572815534,
        "Eccentricity" : 3,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9617049617049618,
        "Stress" : 8088,
        "TopologicalCoefficient" : 0.40970350404312667,
        "countKeyword" : 1,
        "shared_name" : "No escaping",
        "BetweennessCentrality" : 0.006162950178061703,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "No escaping",
        "SelfLoops" : 0,
        "SUID" : 479,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2637362637362637,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.714285714285715
      },
      "position" : {
        "x" : 32.652236109194575,
        "y" : -99.612314162047
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "473",
        "ClosenessCentrality" : 0.441747572815534,
        "Eccentricity" : 3,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9617049617049618,
        "Stress" : 8088,
        "TopologicalCoefficient" : 0.40970350404312667,
        "countKeyword" : 1,
        "shared_name" : "Relentlessly)",
        "BetweennessCentrality" : 0.006162950178061703,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "Relentlessly)",
        "SelfLoops" : 0,
        "SUID" : 473,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2637362637362637,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.714285714285715
      },
      "position" : {
        "x" : -63.26979147869605,
        "y" : -151.5293521259142
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "ClosenessCentrality" : 0.441747572815534,
        "Eccentricity" : 3,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9617049617049618,
        "Stress" : 8088,
        "TopologicalCoefficient" : 0.40970350404312667,
        "countKeyword" : 1,
        "shared_name" : "Hunting",
        "BetweennessCentrality" : 0.006162950178061703,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "Hunting",
        "SelfLoops" : 0,
        "SUID" : 467,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2637362637362637,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.714285714285715
      },
      "position" : {
        "x" : -16.625656957211675,
        "y" : -187.96836274603137
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "458",
        "ClosenessCentrality" : 0.441747572815534,
        "Eccentricity" : 3,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9617049617049618,
        "Stress" : 8088,
        "TopologicalCoefficient" : 0.40970350404312667,
        "countKeyword" : 1,
        "shared_name" : "The eyes",
        "BetweennessCentrality" : 0.006162950178061703,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "The eyes",
        "SelfLoops" : 0,
        "SUID" : 458,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2637362637362637,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.714285714285715
      },
      "position" : {
        "x" : 54.24302590411645,
        "y" : -119.80123322942981
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "452",
        "ClosenessCentrality" : 0.441747572815534,
        "Eccentricity" : 3,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9617049617049618,
        "Stress" : 8088,
        "TopologicalCoefficient" : 0.40970350404312667,
        "countKeyword" : 1,
        "shared_name" : "Always watching",
        "BetweennessCentrality" : 0.006162950178061703,
        "NumberOfUndirectedEdges" : 7,
        "ck_label" : "countKeyword",
        "name" : "Always watching",
        "SelfLoops" : 0,
        "SUID" : 452,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2637362637362637,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.714285714285715
      },
      "position" : {
        "x" : -24.8273476310398,
        "y" : -67.30242722967395
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "446",
        "ClosenessCentrality" : 0.446078431372549,
        "Eccentricity" : 3,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9623709623709624,
        "Stress" : 10526,
        "TopologicalCoefficient" : 0.38207547169811323,
        "countKeyword" : 1,
        "shared_name" : "I can feel it",
        "BetweennessCentrality" : 0.008704987687816787,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "I can feel it",
        "SelfLoops" : 0,
        "SUID" : 446,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.241758241758242,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.25
      },
      "position" : {
        "x" : 7.9571982673977,
        "y" : -37.879564223082156
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "440",
        "ClosenessCentrality" : 0.446078431372549,
        "Eccentricity" : 3,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9623709623709624,
        "Stress" : 10526,
        "TopologicalCoefficient" : 0.38207547169811323,
        "countKeyword" : 1,
        "shared_name" : "gaps of my teeth",
        "BetweennessCentrality" : 0.008704987687816787,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "gaps of my teeth",
        "SelfLoops" : 0,
        "SUID" : 440,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.241758241758242,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.25
      },
      "position" : {
        "x" : -79.60112082439917,
        "y" : 7.210844102113157
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "434",
        "ClosenessCentrality" : 0.446078431372549,
        "Eccentricity" : 3,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9623709623709624,
        "Stress" : 10526,
        "TopologicalCoefficient" : 0.38207547169811323,
        "countKeyword" : 1,
        "shared_name" : "poke out my nostrils",
        "BetweennessCentrality" : 0.008704987687816787,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "poke out my nostrils",
        "SelfLoops" : 0,
        "SUID" : 434,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.241758241758242,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.25
      },
      "position" : {
        "x" : -24.160202855649175,
        "y" : 25.622224869935422
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "428",
        "ClosenessCentrality" : 0.446078431372549,
        "Eccentricity" : 3,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9623709623709624,
        "Stress" : 10526,
        "TopologicalCoefficient" : 0.38207547169811323,
        "countKeyword" : 1,
        "shared_name" : "pushes at my nerves",
        "BetweennessCentrality" : 0.008704987687816787,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "pushes at my nerves",
        "SelfLoops" : 0,
        "SUID" : 428,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.241758241758242,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.25
      },
      "position" : {
        "x" : -42.113755101742925,
        "y" : -11.108132300169558
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "422",
        "ClosenessCentrality" : 0.446078431372549,
        "Eccentricity" : 3,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9623709623709624,
        "Stress" : 10526,
        "TopologicalCoefficient" : 0.38207547169811323,
        "countKeyword" : 1,
        "shared_name" : "too big for my body",
        "BetweennessCentrality" : 0.008704987687816787,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "too big for my body",
        "SelfLoops" : 0,
        "SUID" : 422,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.241758241758242,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.25
      },
      "position" : {
        "x" : -59.4363564201023,
        "y" : 21.561761918275266
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "416",
        "ClosenessCentrality" : 0.5,
        "Eccentricity" : 3,
        "Degree" : 20,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.08496732026143791,
        "Radiality" : 0.9696969696969697,
        "Stress" : 29352,
        "TopologicalCoefficient" : 0.20209339774557167,
        "countKeyword" : 3,
        "shared_name" : "beat",
        "BetweennessCentrality" : 0.06968649797244879,
        "NumberOfUndirectedEdges" : 20,
        "ck_label" : "countKeyword",
        "name" : "beat",
        "SelfLoops" : 0,
        "SUID" : 416,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.166666666666666
      },
      "position" : {
        "x" : -34.76210104900855,
        "y" : 67.04375273248425
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "410",
        "ClosenessCentrality" : 0.5055555555555555,
        "Eccentricity" : 4,
        "Degree" : 29,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9703629703629704,
        "Stress" : 62798,
        "TopologicalCoefficient" : 0.19454887218045114,
        "shared_name" : "anxiety",
        "BetweennessCentrality" : 0.07516566482063113,
        "NumberOfUndirectedEdges" : 29,
        "name" : "anxiety",
        "SelfLoops" : 0,
        "SUID" : 410,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.978021978021978,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.392857142857142
      },
      "position" : {
        "x" : -114.26403891521949,
        "y" : -123.59211915472278
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "404",
        "ClosenessCentrality" : 0.3760330578512397,
        "Eccentricity" : 5,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9497169497169496,
        "Stress" : 982,
        "TopologicalCoefficient" : 0.35135135135135137,
        "countKeyword" : 1,
        "shared_name" : "wrongness",
        "BetweennessCentrality" : 0.003220851255274405,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "wrongness",
        "SelfLoops" : 0,
        "SUID" : 404,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.659340659340659,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : 74.24265969317895,
        "y" : 58.11615568658581
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "395",
        "ClosenessCentrality" : 0.3760330578512397,
        "Eccentricity" : 5,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9497169497169496,
        "Stress" : 982,
        "TopologicalCoefficient" : 0.35135135135135137,
        "countKeyword" : 1,
        "shared_name" : "pallidity",
        "BetweennessCentrality" : 0.003220851255274405,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "pallidity",
        "SelfLoops" : 0,
        "SUID" : 395,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.659340659340659,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : 59.66477883380395,
        "y" : 212.55832487603894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "ClosenessCentrality" : 0.3760330578512397,
        "Eccentricity" : 5,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9497169497169496,
        "Stress" : 982,
        "TopologicalCoefficient" : 0.35135135135135137,
        "countKeyword" : 1,
        "shared_name" : "withering",
        "BetweennessCentrality" : 0.003220851255274405,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "withering",
        "SelfLoops" : 0,
        "SUID" : 389,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.659340659340659,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : 134.0840293220852,
        "y" : 174.91695219537488
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "380",
        "ClosenessCentrality" : 0.3760330578512397,
        "Eccentricity" : 5,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9497169497169496,
        "Stress" : 982,
        "TopologicalCoefficient" : 0.35135135135135137,
        "countKeyword" : 1,
        "shared_name" : "vacancy",
        "BetweennessCentrality" : 0.003220851255274405,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "vacancy",
        "SelfLoops" : 0,
        "SUID" : 380,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.659340659340659,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : 180.5636435798977,
        "y" : 78.49765593072644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "374",
        "ClosenessCentrality" : 0.3760330578512397,
        "Eccentricity" : 5,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9497169497169496,
        "Stress" : 982,
        "TopologicalCoefficient" : 0.35135135135135137,
        "countKeyword" : 1,
        "shared_name" : "void",
        "BetweennessCentrality" : 0.003220851255274405,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "void",
        "SelfLoops" : 0,
        "SUID" : 374,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.659340659340659,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : 25.25755227130395,
        "y" : 246.1162777568983
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "ClosenessCentrality" : 0.3760330578512397,
        "Eccentricity" : 5,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9497169497169496,
        "Stress" : 982,
        "TopologicalCoefficient" : 0.35135135135135137,
        "countKeyword" : 2,
        "shared_name" : "hollow",
        "BetweennessCentrality" : 0.003220851255274405,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "hollow",
        "SelfLoops" : 0,
        "SUID" : 368,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.659340659340659,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : 112.9780722908352,
        "y" : 245.3515988018202
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "362",
        "ClosenessCentrality" : 0.39224137931034486,
        "Eccentricity" : 4,
        "Degree" : 9,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9530469530469531,
        "Stress" : 5552,
        "TopologicalCoefficient" : 0.3942652329749104,
        "shared_name" : "anorexia",
        "BetweennessCentrality" : 0.00532059926606905,
        "NumberOfUndirectedEdges" : 9,
        "name" : "anorexia",
        "SelfLoops" : 0,
        "SUID" : 362,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5494505494505493,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.222222222222221
      },
      "position" : {
        "x" : 74.94789040606958,
        "y" : 232.7440548565077
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "335",
        "ClosenessCentrality" : 0.3872340425531915,
        "Eccentricity" : 4,
        "Degree" : 8,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.25,
        "Radiality" : 0.952047952047952,
        "Stress" : 3898,
        "TopologicalCoefficient" : 0.40131578947368424,
        "shared_name" : "anger",
        "BetweennessCentrality" : 0.003400663653408087,
        "NumberOfUndirectedEdges" : 8,
        "name" : "anger",
        "SelfLoops" : 0,
        "SUID" : 335,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5824175824175826,
        "selected" : false,
        "NeighborhoodConnectivity" : 15.25
      },
      "position" : {
        "x" : 116.47138894122583,
        "y" : -95.15901368597278
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "ClosenessCentrality" : 0.36991869918699183,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9483849483849484,
        "Stress" : 1022,
        "TopologicalCoefficient" : 0.3939393939393939,
        "countKeyword" : 1,
        "shared_name" : "alight in tremors",
        "BetweennessCentrality" : 0.003121543824880187,
        "NumberOfUndirectedEdges" : 6,
        "ck_label" : "countKeyword",
        "name" : "alight in tremors",
        "SelfLoops" : 0,
        "SUID" : 326,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.7032967032967035,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -201.79615103680152,
        "y" : 26.680543961732297
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "ClosenessCentrality" : 0.36991869918699183,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9483849483849484,
        "Stress" : 1022,
        "TopologicalCoefficient" : 0.3939393939393939,
        "countKeyword" : 1,
        "shared_name" : "greying stains",
        "BetweennessCentrality" : 0.003121543824880187,
        "NumberOfUndirectedEdges" : 6,
        "ck_label" : "countKeyword",
        "name" : "greying stains",
        "SelfLoops" : 0,
        "SUID" : 320,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.7032967032967035,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -236.7843025870945,
        "y" : 82.02048307916394
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "314",
        "ClosenessCentrality" : 0.36991869918699183,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9483849483849484,
        "Stress" : 1022,
        "TopologicalCoefficient" : 0.3939393939393939,
        "countKeyword" : 1,
        "shared_name" : "spiraling grain",
        "BetweennessCentrality" : 0.003121543824880187,
        "NumberOfUndirectedEdges" : 6,
        "ck_label" : "countKeyword",
        "name" : "spiraling grain",
        "SelfLoops" : 0,
        "SUID" : 314,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.7032967032967035,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -456.74023193284904,
        "y" : 30.59516181835795
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "304",
        "ClosenessCentrality" : 0.5,
        "Eccentricity" : 3,
        "Degree" : 21,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.1568627450980392,
        "Radiality" : 0.9696969696969697,
        "Stress" : 23316,
        "TopologicalCoefficient" : 0.17857142857142858,
        "countKeyword" : 2,
        "shared_name" : "heartbeat",
        "BetweennessCentrality" : 0.06253696004567232,
        "NumberOfUndirectedEdges" : 20,
        "ck_label" : "countKeyword",
        "name" : "heartbeat",
        "SelfLoops" : 1,
        "SUID" : 304,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.666666666666666
      },
      "position" : {
        "x" : -42.7847450919773,
        "y" : 106.02805906793347
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "ClosenessCentrality" : 0.4026548672566372,
        "Eccentricity" : 4,
        "Degree" : 6,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9550449550449551,
        "Stress" : 2836,
        "TopologicalCoefficient" : 0.37719298245614036,
        "shared_name" : "aging",
        "BetweennessCentrality" : 0.005644895744923629,
        "NumberOfUndirectedEdges" : 6,
        "name" : "aging",
        "SelfLoops" : 0,
        "SUID" : 302,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.4835164835164836,
        "selected" : false,
        "NeighborhoodConnectivity" : 15.333333333333334
      },
      "position" : {
        "x" : 470.1424661803902,
        "y" : -126.8596643369179
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "ClosenessCentrality" : 0.37448559670781895,
        "Eccentricity" : 5,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.25,
        "Radiality" : 0.9493839493839493,
        "Stress" : 954,
        "TopologicalCoefficient" : 0.3778409090909091,
        "countKeyword" : 1,
        "shared_name" : "germs",
        "BetweennessCentrality" : 0.0023867889593820373,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "germs",
        "SelfLoops" : 0,
        "SUID" : 296,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.67032967032967,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.625
      },
      "position" : {
        "x" : 240.52418435138208,
        "y" : -26.07523911932239
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "ClosenessCentrality" : 0.37448559670781895,
        "Eccentricity" : 5,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.25,
        "Radiality" : 0.9493839493839493,
        "Stress" : 954,
        "TopologicalCoefficient" : 0.3778409090909091,
        "countKeyword" : 1,
        "shared_name" : "slap",
        "BetweennessCentrality" : 0.0023867889593820373,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "slap",
        "SelfLoops" : 0,
        "SUID" : 290,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.67032967032967,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.625
      },
      "position" : {
        "x" : 169.2656699470852,
        "y" : 115.14565092584363
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "284",
        "ClosenessCentrality" : 0.37448559670781895,
        "Eccentricity" : 5,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.25,
        "Radiality" : 0.9493839493839493,
        "Stress" : 954,
        "TopologicalCoefficient" : 0.3778409090909091,
        "countKeyword" : 1,
        "shared_name" : "growth",
        "BetweennessCentrality" : 0.0023867889593820373,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "growth",
        "SelfLoops" : 0,
        "SUID" : 284,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.67032967032967,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.625
      },
      "position" : {
        "x" : 263.8916159920071,
        "y" : 28.890321793763547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "ClosenessCentrality" : 0.39737991266375544,
        "Eccentricity" : 5,
        "Degree" : 16,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.06666666666666667,
        "Radiality" : 0.954045954045954,
        "Stress" : 4380,
        "TopologicalCoefficient" : 0.3242424242424242,
        "countKeyword" : 1,
        "shared_name" : "blood",
        "BetweennessCentrality" : 0.01709880274944247,
        "NumberOfUndirectedEdges" : 16,
        "ck_label" : "countKeyword",
        "name" : "blood",
        "SelfLoops" : 0,
        "SUID" : 278,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5164835164835164,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.733333333333333
      },
      "position" : {
        "x" : 202.93824685138208,
        "y" : 157.04839140435925
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "ClosenessCentrality" : 0.37448559670781895,
        "Eccentricity" : 5,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.25,
        "Radiality" : 0.9493839493839493,
        "Stress" : 954,
        "TopologicalCoefficient" : 0.3778409090909091,
        "countKeyword" : 1,
        "shared_name" : "fuzzing",
        "BetweennessCentrality" : 0.0023867889593820373,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "fuzzing",
        "SelfLoops" : 0,
        "SUID" : 272,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.67032967032967,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.625
      },
      "position" : {
        "x" : 233.84779274981958,
        "y" : 94.18266874810925
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "ClosenessCentrality" : 0.37448559670781895,
        "Eccentricity" : 5,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.25,
        "Radiality" : 0.9493839493839493,
        "Stress" : 954,
        "TopologicalCoefficient" : 0.3778409090909091,
        "countKeyword" : 1,
        "shared_name" : "spores",
        "BetweennessCentrality" : 0.0023867889593820373,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "spores",
        "SelfLoops" : 0,
        "SUID" : 266,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.67032967032967,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.625
      },
      "position" : {
        "x" : 149.82405007403833,
        "y" : 198.96059233209363
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "ClosenessCentrality" : 0.37448559670781895,
        "Eccentricity" : 5,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.25,
        "Radiality" : 0.9493839493839493,
        "Stress" : 954,
        "TopologicalCoefficient" : 0.3778409090909091,
        "countKeyword" : 1,
        "shared_name" : "rot",
        "BetweennessCentrality" : 0.0023867889593820373,
        "NumberOfUndirectedEdges" : 8,
        "ck_label" : "countKeyword",
        "name" : "rot",
        "SelfLoops" : 0,
        "SUID" : 260,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.67032967032967,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.625
      },
      "position" : {
        "x" : 240.19013894122583,
        "y" : 101.29305082818738
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "ClosenessCentrality" : 0.45499999999999996,
        "Eccentricity" : 4,
        "Degree" : 17,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.5333333333333333,
        "Radiality" : 0.9637029637029637,
        "Stress" : 3026,
        "TopologicalCoefficient" : 0.2262295081967213,
        "countKeyword" : 1,
        "shared_name" : "mold",
        "BetweennessCentrality" : 0.005344706035480226,
        "NumberOfUndirectedEdges" : 16,
        "ck_label" : "countKeyword",
        "name" : "mold",
        "SelfLoops" : 1,
        "SUID" : 254,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.197802197802198,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.8
      },
      "position" : {
        "x" : 186.67030251544458,
        "y" : 94.0701809551405
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "ClosenessCentrality" : 0.3807531380753138,
        "Eccentricity" : 5,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.2,
        "Radiality" : 0.9507159507159507,
        "Stress" : 1160,
        "TopologicalCoefficient" : 0.3173913043478261,
        "countKeyword" : 1,
        "shared_name" : "copper",
        "BetweennessCentrality" : 0.004047287876580164,
        "NumberOfUndirectedEdges" : 10,
        "ck_label" : "countKeyword",
        "name" : "copper",
        "SelfLoops" : 0,
        "SUID" : 245,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6263736263736264,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.6
      },
      "position" : {
        "x" : 250.22682107013208,
        "y" : -89.67370027044544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "239",
        "ClosenessCentrality" : 0.3807531380753138,
        "Eccentricity" : 5,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.2,
        "Radiality" : 0.9507159507159507,
        "Stress" : 1160,
        "TopologicalCoefficient" : 0.3173913043478261,
        "countKeyword" : 1,
        "shared_name" : "blowtorch",
        "BetweennessCentrality" : 0.004047287876580164,
        "NumberOfUndirectedEdges" : 10,
        "ck_label" : "countKeyword",
        "name" : "blowtorch",
        "SelfLoops" : 0,
        "SUID" : 239,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6263736263736264,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.6
      },
      "position" : {
        "x" : 544.1712063025244,
        "y" : -55.83300796185537
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "ClosenessCentrality" : 0.5352941176470588,
        "Eccentricity" : 3,
        "Degree" : 32,
        "PartnerOfMultiEdgedNodePairs" : 6,
        "ClusteringCoefficient" : 0.04923076923076923,
        "Radiality" : 0.9736929736929737,
        "Stress" : 57146,
        "TopologicalCoefficient" : 0.20355029585798817,
        "countKeyword" : 1,
        "shared_name" : "pain",
        "BetweennessCentrality" : 0.11716224579333372,
        "NumberOfUndirectedEdges" : 32,
        "ck_label" : "countKeyword",
        "name" : "pain",
        "SelfLoops" : 0,
        "SUID" : 233,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.8681318681318682,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.692307692307692
      },
      "position" : {
        "x" : 52.252638941225825,
        "y" : 59.53207975885144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "227",
        "ClosenessCentrality" : 0.3807531380753138,
        "Eccentricity" : 5,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.2,
        "Radiality" : 0.9507159507159507,
        "Stress" : 1160,
        "TopologicalCoefficient" : 0.3173913043478261,
        "countKeyword" : 1,
        "shared_name" : "pay",
        "BetweennessCentrality" : 0.004047287876580164,
        "NumberOfUndirectedEdges" : 10,
        "ck_label" : "countKeyword",
        "name" : "pay",
        "SelfLoops" : 0,
        "SUID" : 227,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6263736263736264,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.6
      },
      "position" : {
        "x" : 219.6845063291616,
        "y" : -187.94259818084706
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "221",
        "ClosenessCentrality" : 0.3807531380753138,
        "Eccentricity" : 5,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.2,
        "Radiality" : 0.9507159507159507,
        "Stress" : 1160,
        "TopologicalCoefficient" : 0.3173913043478261,
        "countKeyword" : 1,
        "shared_name" : "thing",
        "BetweennessCentrality" : 0.004047287876580164,
        "NumberOfUndirectedEdges" : 10,
        "ck_label" : "countKeyword",
        "name" : "thing",
        "SelfLoops" : 0,
        "SUID" : 221,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6263736263736264,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.6
      },
      "position" : {
        "x" : 158.82997048419458,
        "y" : -37.67619889715442
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "215",
        "ClosenessCentrality" : 0.3807531380753138,
        "Eccentricity" : 5,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.2,
        "Radiality" : 0.9507159507159507,
        "Stress" : 1160,
        "TopologicalCoefficient" : 0.3173913043478261,
        "countKeyword" : 1,
        "shared_name" : "searing",
        "BetweennessCentrality" : 0.004047287876580164,
        "NumberOfUndirectedEdges" : 10,
        "ck_label" : "countKeyword",
        "name" : "searing",
        "SelfLoops" : 0,
        "SUID" : 215,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6263736263736264,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.6
      },
      "position" : {
        "x" : 428.44391190022,
        "y" : -219.4930255169771
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "209",
        "ClosenessCentrality" : 0.47150259067357514,
        "Eccentricity" : 4,
        "Degree" : 18,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.525,
        "Radiality" : 0.9660339660339661,
        "Stress" : 5058,
        "TopologicalCoefficient" : 0.22014925373134328,
        "countKeyword" : 1,
        "shared_name" : "redness",
        "BetweennessCentrality" : 0.007447951529988245,
        "NumberOfUndirectedEdges" : 17,
        "ck_label" : "countKeyword",
        "name" : "redness",
        "SelfLoops" : 1,
        "SUID" : 209,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.120879120879121,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.75
      },
      "position" : {
        "x" : 162.6439658455227,
        "y" : -78.8290995929552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "181",
        "ClosenessCentrality" : 0.5652173913043479,
        "Eccentricity" : 3,
        "Degree" : 39,
        "PartnerOfMultiEdgedNodePairs" : 6,
        "ClusteringCoefficient" : 0.020689655172413793,
        "Radiality" : 0.9766899766899768,
        "Stress" : 95436,
        "TopologicalCoefficient" : 0.21505376344086022,
        "countKeyword" : 5,
        "shared_name" : "me",
        "BetweennessCentrality" : 0.18578225743133248,
        "NumberOfUndirectedEdges" : 39,
        "ck_label" : "countKeyword",
        "name" : "me",
        "SelfLoops" : 0,
        "SUID" : 181,
        "Target_Desc" : "keyword",
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.7692307692307692,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : 451.7496736970171,
        "y" : 66.02783104487989
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "179",
        "ClosenessCentrality" : 0.41363636363636364,
        "Eccentricity" : 4,
        "Degree" : 17,
        "Source_Desc" : "tagpoint",
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.125,
        "Radiality" : 0.957042957042957,
        "Stress" : 10386,
        "TopologicalCoefficient" : 0.2777777777777778,
        "shared_name" : "abuse",
        "BetweennessCentrality" : 0.014526020833527106,
        "NumberOfUndirectedEdges" : 17,
        "name" : "abuse",
        "SelfLoops" : 0,
        "SUID" : 179,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.4175824175824174,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.5
      },
      "position" : {
        "x" : 180.48924172442895,
        "y" : 4.324323716370969
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "1991",
        "source" : "1952",
        "target" : "575",
        "EdgeBetweenness" : 17.428571428571413,
        "shared_name" : "weather (interacts with) rain drop",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "weather (interacts with) rain drop",
        "interaction" : "interacts with",
        "SUID" : 1991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1988",
        "source" : "1952",
        "target" : "569",
        "EdgeBetweenness" : 17.428571428571413,
        "shared_name" : "weather (interacts with) quiet",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "weather (interacts with) quiet",
        "interaction" : "interacts with",
        "SUID" : 1988,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1985",
        "source" : "1952",
        "target" : "563",
        "EdgeBetweenness" : 17.428571428571413,
        "shared_name" : "weather (interacts with) flurry",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "weather (interacts with) flurry",
        "interaction" : "interacts with",
        "SUID" : 1985,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1982",
        "source" : "1952",
        "target" : "557",
        "EdgeBetweenness" : 17.428571428571413,
        "shared_name" : "weather (interacts with) frigid",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "weather (interacts with) frigid",
        "interaction" : "interacts with",
        "SUID" : 1982,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1979",
        "source" : "1952",
        "target" : "551",
        "EdgeBetweenness" : 17.428571428571413,
        "shared_name" : "weather (interacts with) chill",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "weather (interacts with) chill",
        "interaction" : "interacts with",
        "SUID" : 1979,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1976",
        "source" : "1952",
        "target" : "545",
        "EdgeBetweenness" : 17.428571428571413,
        "shared_name" : "weather (interacts with) Howling",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "weather (interacts with) Howling",
        "interaction" : "interacts with",
        "SUID" : 1976,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1973",
        "source" : "1952",
        "target" : "539",
        "EdgeBetweenness" : 17.428571428571413,
        "shared_name" : "weather (interacts with) gale",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "weather (interacts with) gale",
        "interaction" : "interacts with",
        "SUID" : 1973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1970",
        "source" : "1952",
        "target" : "533",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "weather (interacts with) thunder",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "weather (interacts with) thunder",
        "interaction" : "interacts with",
        "SUID" : 1970,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1967",
        "source" : "1952",
        "target" : "527",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "weather (interacts with) raining",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "weather (interacts with) raining",
        "interaction" : "interacts with",
        "SUID" : 1967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1964",
        "source" : "1952",
        "target" : "521",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "weather (interacts with) frightening",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "weather (interacts with) frightening",
        "interaction" : "interacts with",
        "SUID" : 1964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1961",
        "source" : "1952",
        "target" : "515",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "weather (interacts with) grey sky",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "weather (interacts with) grey sky",
        "interaction" : "interacts with",
        "SUID" : 1961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1958",
        "source" : "1952",
        "target" : "509",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "weather (interacts with) clouds",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "weather (interacts with) clouds",
        "interaction" : "interacts with",
        "SUID" : 1958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1955",
        "source" : "1952",
        "target" : "503",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "weather (interacts with) air",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "weather (interacts with) air",
        "interaction" : "interacts with",
        "SUID" : 1955,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1949",
        "source" : "1898",
        "target" : "296",
        "EdgeBetweenness" : 18.606658678704374,
        "shared_name" : "toxicity (interacts with) germs",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "toxicity (interacts with) germs",
        "interaction" : "interacts with",
        "SUID" : 1949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1946",
        "source" : "1898",
        "target" : "290",
        "EdgeBetweenness" : 18.60665867870437,
        "shared_name" : "toxicity (interacts with) slap",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "toxicity (interacts with) slap",
        "interaction" : "interacts with",
        "SUID" : 1946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1943",
        "source" : "1898",
        "target" : "284",
        "EdgeBetweenness" : 18.60665867870437,
        "shared_name" : "toxicity (interacts with) growth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "toxicity (interacts with) growth",
        "interaction" : "interacts with",
        "SUID" : 1943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1940",
        "source" : "1898",
        "target" : "278",
        "EdgeBetweenness" : 25.941152857280787,
        "shared_name" : "toxicity (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "toxicity (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 1940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1937",
        "source" : "1898",
        "target" : "272",
        "EdgeBetweenness" : 18.606658678704367,
        "shared_name" : "toxicity (interacts with) fuzzing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "toxicity (interacts with) fuzzing",
        "interaction" : "interacts with",
        "SUID" : 1937,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1934",
        "source" : "1898",
        "target" : "266",
        "EdgeBetweenness" : 18.606658678704363,
        "shared_name" : "toxicity (interacts with) spores",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "toxicity (interacts with) spores",
        "interaction" : "interacts with",
        "SUID" : 1934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1931",
        "source" : "1898",
        "target" : "260",
        "EdgeBetweenness" : 18.606658678704363,
        "shared_name" : "toxicity (interacts with) rot",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "toxicity (interacts with) rot",
        "interaction" : "interacts with",
        "SUID" : 1931,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1928",
        "source" : "1898",
        "target" : "254",
        "EdgeBetweenness" : 9.628031527151222,
        "shared_name" : "toxicity (interacts with) mold",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "toxicity (interacts with) mold",
        "interaction" : "interacts with",
        "SUID" : 1928,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1925",
        "source" : "1898",
        "target" : "233",
        "EdgeBetweenness" : 63.172037464201956,
        "shared_name" : "toxicity (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "toxicity (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1922",
        "source" : "1898",
        "target" : "245",
        "EdgeBetweenness" : 18.134625009875617,
        "shared_name" : "toxicity (interacts with) copper",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "toxicity (interacts with) copper",
        "interaction" : "interacts with",
        "SUID" : 1922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1919",
        "source" : "1898",
        "target" : "239",
        "EdgeBetweenness" : 18.134625009875617,
        "shared_name" : "toxicity (interacts with) blowtorch",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "toxicity (interacts with) blowtorch",
        "interaction" : "interacts with",
        "SUID" : 1919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1916",
        "source" : "1898",
        "target" : "233",
        "EdgeBetweenness" : 63.172037464201956,
        "shared_name" : "toxicity (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "toxicity (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1916,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1913",
        "source" : "1898",
        "target" : "227",
        "EdgeBetweenness" : 18.13462500987563,
        "shared_name" : "toxicity (interacts with) pay",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "toxicity (interacts with) pay",
        "interaction" : "interacts with",
        "SUID" : 1913,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1910",
        "source" : "1898",
        "target" : "221",
        "EdgeBetweenness" : 18.13462500987563,
        "shared_name" : "toxicity (interacts with) thing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "toxicity (interacts with) thing",
        "interaction" : "interacts with",
        "SUID" : 1910,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1907",
        "source" : "1898",
        "target" : "215",
        "EdgeBetweenness" : 18.134625009875627,
        "shared_name" : "toxicity (interacts with) searing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "toxicity (interacts with) searing",
        "interaction" : "interacts with",
        "SUID" : 1907,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1904",
        "source" : "1898",
        "target" : "209",
        "EdgeBetweenness" : 10.921874238465199,
        "shared_name" : "toxicity (interacts with) redness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "toxicity (interacts with) redness",
        "interaction" : "interacts with",
        "SUID" : 1904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1901",
        "source" : "1898",
        "target" : "181",
        "EdgeBetweenness" : 107.96004804447041,
        "shared_name" : "toxicity (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "toxicity (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1901,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1895",
        "source" : "1868",
        "target" : "416",
        "EdgeBetweenness" : 41.255785742166616,
        "shared_name" : "time (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "time (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 1895,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1892",
        "source" : "1868",
        "target" : "662",
        "EdgeBetweenness" : 30.95704977261332,
        "shared_name" : "time (interacts with) Heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "time (interacts with) Heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1892,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1889",
        "source" : "1868",
        "target" : "304",
        "EdgeBetweenness" : 31.240697943092343,
        "shared_name" : "time (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "time (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1889,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1886",
        "source" : "1868",
        "target" : "181",
        "EdgeBetweenness" : 77.76655063722178,
        "shared_name" : "time (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "time (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1886,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1883",
        "source" : "1868",
        "target" : "326",
        "EdgeBetweenness" : 29.541458052490015,
        "shared_name" : "time (interacts with) alight in tremors",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "time (interacts with) alight in tremors",
        "interaction" : "interacts with",
        "SUID" : 1883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1880",
        "source" : "1868",
        "target" : "320",
        "EdgeBetweenness" : 29.541458052490018,
        "shared_name" : "time (interacts with) greying stains",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "time (interacts with) greying stains",
        "interaction" : "interacts with",
        "SUID" : 1880,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1877",
        "source" : "1868",
        "target" : "314",
        "EdgeBetweenness" : 29.54145805249002,
        "shared_name" : "time (interacts with) spiraling grain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "time (interacts with) spiraling grain",
        "interaction" : "interacts with",
        "SUID" : 1877,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1874",
        "source" : "1868",
        "target" : "233",
        "EdgeBetweenness" : 68.04737764302406,
        "shared_name" : "time (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "time (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1874,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1871",
        "source" : "1868",
        "target" : "304",
        "EdgeBetweenness" : 31.240697943092343,
        "shared_name" : "time (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "time (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1871,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1865",
        "source" : "1826",
        "target" : "575",
        "EdgeBetweenness" : 17.428571428571416,
        "shared_name" : "tension (interacts with) rain drop",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "tension (interacts with) rain drop",
        "interaction" : "interacts with",
        "SUID" : 1865,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1862",
        "source" : "1826",
        "target" : "569",
        "EdgeBetweenness" : 17.428571428571416,
        "shared_name" : "tension (interacts with) quiet",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "tension (interacts with) quiet",
        "interaction" : "interacts with",
        "SUID" : 1862,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1859",
        "source" : "1826",
        "target" : "563",
        "EdgeBetweenness" : 17.428571428571416,
        "shared_name" : "tension (interacts with) flurry",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "tension (interacts with) flurry",
        "interaction" : "interacts with",
        "SUID" : 1859,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1856",
        "source" : "1826",
        "target" : "557",
        "EdgeBetweenness" : 17.428571428571416,
        "shared_name" : "tension (interacts with) frigid",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "tension (interacts with) frigid",
        "interaction" : "interacts with",
        "SUID" : 1856,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1853",
        "source" : "1826",
        "target" : "551",
        "EdgeBetweenness" : 17.428571428571416,
        "shared_name" : "tension (interacts with) chill",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "tension (interacts with) chill",
        "interaction" : "interacts with",
        "SUID" : 1853,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1850",
        "source" : "1826",
        "target" : "545",
        "EdgeBetweenness" : 17.428571428571413,
        "shared_name" : "tension (interacts with) Howling",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "tension (interacts with) Howling",
        "interaction" : "interacts with",
        "SUID" : 1850,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1847",
        "source" : "1826",
        "target" : "539",
        "EdgeBetweenness" : 17.428571428571413,
        "shared_name" : "tension (interacts with) gale",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "tension (interacts with) gale",
        "interaction" : "interacts with",
        "SUID" : 1847,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1844",
        "source" : "1826",
        "target" : "533",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "tension (interacts with) thunder",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "tension (interacts with) thunder",
        "interaction" : "interacts with",
        "SUID" : 1844,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1841",
        "source" : "1826",
        "target" : "527",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "tension (interacts with) raining",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "tension (interacts with) raining",
        "interaction" : "interacts with",
        "SUID" : 1841,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1838",
        "source" : "1826",
        "target" : "521",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "tension (interacts with) frightening",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "tension (interacts with) frightening",
        "interaction" : "interacts with",
        "SUID" : 1838,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1835",
        "source" : "1826",
        "target" : "515",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "tension (interacts with) grey sky",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "tension (interacts with) grey sky",
        "interaction" : "interacts with",
        "SUID" : 1835,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1832",
        "source" : "1826",
        "target" : "509",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "tension (interacts with) clouds",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "tension (interacts with) clouds",
        "interaction" : "interacts with",
        "SUID" : 1832,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1829",
        "source" : "1826",
        "target" : "503",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "tension (interacts with) air",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "tension (interacts with) air",
        "interaction" : "interacts with",
        "SUID" : 1829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1823",
        "source" : "1796",
        "target" : "497",
        "EdgeBetweenness" : 16.627177047765127,
        "shared_name" : "stalking (interacts with) Witnessed.",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "stalking (interacts with) Witnessed.",
        "interaction" : "interacts with",
        "SUID" : 1823,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1820",
        "source" : "1796",
        "target" : "491",
        "EdgeBetweenness" : 16.62717704776512,
        "shared_name" : "stalking (interacts with) Never",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "stalking (interacts with) Never",
        "interaction" : "interacts with",
        "SUID" : 1820,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1817",
        "source" : "1796",
        "target" : "485",
        "EdgeBetweenness" : 16.627177047765123,
        "shared_name" : "stalking (interacts with) They see it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "stalking (interacts with) They see it",
        "interaction" : "interacts with",
        "SUID" : 1817,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1814",
        "source" : "1796",
        "target" : "479",
        "EdgeBetweenness" : 16.627177047765127,
        "shared_name" : "stalking (interacts with) No escaping",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "stalking (interacts with) No escaping",
        "interaction" : "interacts with",
        "SUID" : 1814,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1811",
        "source" : "1796",
        "target" : "473",
        "EdgeBetweenness" : 16.627177047765127,
        "shared_name" : "stalking (interacts with) Relentlessly)",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "stalking (interacts with) Relentlessly)",
        "interaction" : "interacts with",
        "SUID" : 1811,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1808",
        "source" : "1796",
        "target" : "467",
        "EdgeBetweenness" : 16.627177047765127,
        "shared_name" : "stalking (interacts with) Hunting",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "stalking (interacts with) Hunting",
        "interaction" : "interacts with",
        "SUID" : 1808,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1805",
        "source" : "1796",
        "target" : "181",
        "EdgeBetweenness" : 101.27195596816335,
        "shared_name" : "stalking (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "stalking (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1805,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1802",
        "source" : "1796",
        "target" : "458",
        "EdgeBetweenness" : 16.627177047765127,
        "shared_name" : "stalking (interacts with) The eyes",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "stalking (interacts with) The eyes",
        "interaction" : "interacts with",
        "SUID" : 1802,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1799",
        "source" : "1796",
        "target" : "452",
        "EdgeBetweenness" : 16.627177047765127,
        "shared_name" : "stalking (interacts with) Always watching",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "stalking (interacts with) Always watching",
        "interaction" : "interacts with",
        "SUID" : 1799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1793",
        "source" : "1766",
        "target" : "404",
        "EdgeBetweenness" : 14.496111431395454,
        "shared_name" : "self-harm (interacts with) wrongness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "self-harm (interacts with) wrongness",
        "interaction" : "interacts with",
        "SUID" : 1793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1790",
        "source" : "1766",
        "target" : "278",
        "EdgeBetweenness" : 24.65794126754637,
        "shared_name" : "self-harm (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "self-harm (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 1790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1787",
        "source" : "1766",
        "target" : "395",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "self-harm (interacts with) pallidity",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "self-harm (interacts with) pallidity",
        "interaction" : "interacts with",
        "SUID" : 1787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1784",
        "source" : "1766",
        "target" : "389",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "self-harm (interacts with) withering",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "self-harm (interacts with) withering",
        "interaction" : "interacts with",
        "SUID" : 1784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1781",
        "source" : "1766",
        "target" : "233",
        "EdgeBetweenness" : 62.50906386930152,
        "shared_name" : "self-harm (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "self-harm (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1781,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1778",
        "source" : "1766",
        "target" : "380",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "self-harm (interacts with) vacancy",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "self-harm (interacts with) vacancy",
        "interaction" : "interacts with",
        "SUID" : 1778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1775",
        "source" : "1766",
        "target" : "374",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "self-harm (interacts with) void",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "self-harm (interacts with) void",
        "interaction" : "interacts with",
        "SUID" : 1775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1772",
        "source" : "1766",
        "target" : "368",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "self-harm (interacts with) hollow",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "self-harm (interacts with) hollow",
        "interaction" : "interacts with",
        "SUID" : 1772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1769",
        "source" : "1766",
        "target" : "181",
        "EdgeBetweenness" : 95.00774225299041,
        "shared_name" : "self-harm (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "self-harm (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1769,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1763",
        "source" : "1700",
        "target" : "296",
        "EdgeBetweenness" : 61.061685469211604,
        "shared_name" : "sadness (interacts with) germs",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "sadness (interacts with) germs",
        "interaction" : "interacts with",
        "SUID" : 1763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1760",
        "source" : "1700",
        "target" : "290",
        "EdgeBetweenness" : 61.0616854692116,
        "shared_name" : "sadness (interacts with) slap",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "sadness (interacts with) slap",
        "interaction" : "interacts with",
        "SUID" : 1760,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1757",
        "source" : "1700",
        "target" : "284",
        "EdgeBetweenness" : 61.0616854692116,
        "shared_name" : "sadness (interacts with) growth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "sadness (interacts with) growth",
        "interaction" : "interacts with",
        "SUID" : 1757,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1754",
        "source" : "1700",
        "target" : "278",
        "EdgeBetweenness" : 51.20476037274668,
        "shared_name" : "sadness (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "sadness (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 1754,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1751",
        "source" : "1700",
        "target" : "272",
        "EdgeBetweenness" : 61.06168546921159,
        "shared_name" : "sadness (interacts with) fuzzing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "sadness (interacts with) fuzzing",
        "interaction" : "interacts with",
        "SUID" : 1751,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1748",
        "source" : "1700",
        "target" : "266",
        "EdgeBetweenness" : 61.06168546921158,
        "shared_name" : "sadness (interacts with) spores",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "sadness (interacts with) spores",
        "interaction" : "interacts with",
        "SUID" : 1748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1745",
        "source" : "1700",
        "target" : "260",
        "EdgeBetweenness" : 61.06168546921158,
        "shared_name" : "sadness (interacts with) rot",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "sadness (interacts with) rot",
        "interaction" : "interacts with",
        "SUID" : 1745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1742",
        "source" : "1700",
        "target" : "254",
        "EdgeBetweenness" : 40.143188188841904,
        "shared_name" : "sadness (interacts with) mold",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "sadness (interacts with) mold",
        "interaction" : "interacts with",
        "SUID" : 1742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1739",
        "source" : "1700",
        "target" : "233",
        "EdgeBetweenness" : 68.73619389778466,
        "shared_name" : "sadness (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "sadness (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1739,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1736",
        "source" : "1700",
        "target" : "497",
        "EdgeBetweenness" : 53.19723577395083,
        "shared_name" : "sadness (interacts with) Witnessed.",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "sadness (interacts with) Witnessed.",
        "interaction" : "interacts with",
        "SUID" : 1736,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1733",
        "source" : "1700",
        "target" : "491",
        "EdgeBetweenness" : 53.197235773950865,
        "shared_name" : "sadness (interacts with) Never",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "sadness (interacts with) Never",
        "interaction" : "interacts with",
        "SUID" : 1733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1730",
        "source" : "1700",
        "target" : "485",
        "EdgeBetweenness" : 53.19723577395086,
        "shared_name" : "sadness (interacts with) They see it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "sadness (interacts with) They see it",
        "interaction" : "interacts with",
        "SUID" : 1730,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1727",
        "source" : "1700",
        "target" : "479",
        "EdgeBetweenness" : 53.197235773950865,
        "shared_name" : "sadness (interacts with) No escaping",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "sadness (interacts with) No escaping",
        "interaction" : "interacts with",
        "SUID" : 1727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1724",
        "source" : "1700",
        "target" : "473",
        "EdgeBetweenness" : 53.19723577395086,
        "shared_name" : "sadness (interacts with) Relentlessly)",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "sadness (interacts with) Relentlessly)",
        "interaction" : "interacts with",
        "SUID" : 1724,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1721",
        "source" : "1700",
        "target" : "467",
        "EdgeBetweenness" : 53.19723577395086,
        "shared_name" : "sadness (interacts with) Hunting",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "sadness (interacts with) Hunting",
        "interaction" : "interacts with",
        "SUID" : 1721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1718",
        "source" : "1700",
        "target" : "181",
        "EdgeBetweenness" : 81.34978103205945,
        "shared_name" : "sadness (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "sadness (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1715",
        "source" : "1700",
        "target" : "458",
        "EdgeBetweenness" : 53.197235773950865,
        "shared_name" : "sadness (interacts with) The eyes",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "sadness (interacts with) The eyes",
        "interaction" : "interacts with",
        "SUID" : 1715,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1712",
        "source" : "1700",
        "target" : "452",
        "EdgeBetweenness" : 53.197235773950865,
        "shared_name" : "sadness (interacts with) Always watching",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "sadness (interacts with) Always watching",
        "interaction" : "interacts with",
        "SUID" : 1712,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1709",
        "source" : "1700",
        "target" : "416",
        "EdgeBetweenness" : 77.90156685305132,
        "shared_name" : "sadness (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "sadness (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 1709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1706",
        "source" : "1700",
        "target" : "662",
        "EdgeBetweenness" : 64.20819112801229,
        "shared_name" : "sadness (interacts with) Heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "sadness (interacts with) Heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1703",
        "source" : "1700",
        "target" : "304",
        "EdgeBetweenness" : 76.59151952918862,
        "shared_name" : "sadness (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "sadness (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1703,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1697",
        "source" : "1670",
        "target" : "296",
        "EdgeBetweenness" : 13.653534795503429,
        "shared_name" : "romance (interacts with) germs",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "romance (interacts with) germs",
        "interaction" : "interacts with",
        "SUID" : 1697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1694",
        "source" : "1670",
        "target" : "290",
        "EdgeBetweenness" : 13.65353479550343,
        "shared_name" : "romance (interacts with) slap",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "romance (interacts with) slap",
        "interaction" : "interacts with",
        "SUID" : 1694,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1691",
        "source" : "1670",
        "target" : "284",
        "EdgeBetweenness" : 13.653534795503434,
        "shared_name" : "romance (interacts with) growth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "romance (interacts with) growth",
        "interaction" : "interacts with",
        "SUID" : 1691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1688",
        "source" : "1670",
        "target" : "278",
        "EdgeBetweenness" : 29.77384491797221,
        "shared_name" : "romance (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "romance (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 1688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1685",
        "source" : "1670",
        "target" : "272",
        "EdgeBetweenness" : 13.653534795503436,
        "shared_name" : "romance (interacts with) fuzzing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "romance (interacts with) fuzzing",
        "interaction" : "interacts with",
        "SUID" : 1685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1682",
        "source" : "1670",
        "target" : "266",
        "EdgeBetweenness" : 13.653534795503436,
        "shared_name" : "romance (interacts with) spores",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "romance (interacts with) spores",
        "interaction" : "interacts with",
        "SUID" : 1682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1679",
        "source" : "1670",
        "target" : "260",
        "EdgeBetweenness" : 13.653534795503438,
        "shared_name" : "romance (interacts with) rot",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "romance (interacts with) rot",
        "interaction" : "interacts with",
        "SUID" : 1679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1676",
        "source" : "1670",
        "target" : "254",
        "EdgeBetweenness" : 9.171258970348513,
        "shared_name" : "romance (interacts with) mold",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "romance (interacts with) mold",
        "interaction" : "interacts with",
        "SUID" : 1676,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1673",
        "source" : "1670",
        "target" : "233",
        "EdgeBetweenness" : 109.58436904514703,
        "shared_name" : "romance (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "romance (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1667",
        "source" : "1616",
        "target" : "296",
        "EdgeBetweenness" : 18.606658678704374,
        "shared_name" : "relationship (interacts with) germs",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "relationship (interacts with) germs",
        "interaction" : "interacts with",
        "SUID" : 1667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1664",
        "source" : "1616",
        "target" : "290",
        "EdgeBetweenness" : 18.606658678704374,
        "shared_name" : "relationship (interacts with) slap",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "relationship (interacts with) slap",
        "interaction" : "interacts with",
        "SUID" : 1664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1661",
        "source" : "1616",
        "target" : "284",
        "EdgeBetweenness" : 18.60665867870437,
        "shared_name" : "relationship (interacts with) growth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "relationship (interacts with) growth",
        "interaction" : "interacts with",
        "SUID" : 1661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1658",
        "source" : "1616",
        "target" : "278",
        "EdgeBetweenness" : 25.94115285728078,
        "shared_name" : "relationship (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "relationship (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 1658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1655",
        "source" : "1616",
        "target" : "272",
        "EdgeBetweenness" : 18.606658678704367,
        "shared_name" : "relationship (interacts with) fuzzing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "relationship (interacts with) fuzzing",
        "interaction" : "interacts with",
        "SUID" : 1655,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1652",
        "source" : "1616",
        "target" : "266",
        "EdgeBetweenness" : 18.606658678704367,
        "shared_name" : "relationship (interacts with) spores",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "relationship (interacts with) spores",
        "interaction" : "interacts with",
        "SUID" : 1652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1649",
        "source" : "1616",
        "target" : "260",
        "EdgeBetweenness" : 18.606658678704367,
        "shared_name" : "relationship (interacts with) rot",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "relationship (interacts with) rot",
        "interaction" : "interacts with",
        "SUID" : 1649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1646",
        "source" : "1616",
        "target" : "254",
        "EdgeBetweenness" : 9.628031527151217,
        "shared_name" : "relationship (interacts with) mold",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "relationship (interacts with) mold",
        "interaction" : "interacts with",
        "SUID" : 1646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1643",
        "source" : "1616",
        "target" : "233",
        "EdgeBetweenness" : 63.17203746420197,
        "shared_name" : "relationship (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "relationship (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1640",
        "source" : "1616",
        "target" : "245",
        "EdgeBetweenness" : 18.13462500987562,
        "shared_name" : "relationship (interacts with) copper",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "relationship (interacts with) copper",
        "interaction" : "interacts with",
        "SUID" : 1640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1637",
        "source" : "1616",
        "target" : "239",
        "EdgeBetweenness" : 18.13462500987562,
        "shared_name" : "relationship (interacts with) blowtorch",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "relationship (interacts with) blowtorch",
        "interaction" : "interacts with",
        "SUID" : 1637,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1634",
        "source" : "1616",
        "target" : "233",
        "EdgeBetweenness" : 63.17203746420197,
        "shared_name" : "relationship (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "relationship (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1631",
        "source" : "1616",
        "target" : "227",
        "EdgeBetweenness" : 18.134625009875627,
        "shared_name" : "relationship (interacts with) pay",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "relationship (interacts with) pay",
        "interaction" : "interacts with",
        "SUID" : 1631,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1628",
        "source" : "1616",
        "target" : "221",
        "EdgeBetweenness" : 18.134625009875627,
        "shared_name" : "relationship (interacts with) thing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "relationship (interacts with) thing",
        "interaction" : "interacts with",
        "SUID" : 1628,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1625",
        "source" : "1616",
        "target" : "215",
        "EdgeBetweenness" : 18.13462500987563,
        "shared_name" : "relationship (interacts with) searing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "relationship (interacts with) searing",
        "interaction" : "interacts with",
        "SUID" : 1625,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1622",
        "source" : "1616",
        "target" : "209",
        "EdgeBetweenness" : 10.921874238465197,
        "shared_name" : "relationship (interacts with) redness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "relationship (interacts with) redness",
        "interaction" : "interacts with",
        "SUID" : 1622,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1619",
        "source" : "1616",
        "target" : "181",
        "EdgeBetweenness" : 107.96004804447041,
        "shared_name" : "relationship (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "relationship (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1589",
        "source" : "1550",
        "target" : "575",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "rain (interacts with) rain drop",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "rain (interacts with) rain drop",
        "interaction" : "interacts with",
        "SUID" : 1589,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1586",
        "source" : "1550",
        "target" : "569",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "rain (interacts with) quiet",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "rain (interacts with) quiet",
        "interaction" : "interacts with",
        "SUID" : 1586,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1583",
        "source" : "1550",
        "target" : "563",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "rain (interacts with) flurry",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "rain (interacts with) flurry",
        "interaction" : "interacts with",
        "SUID" : 1583,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1580",
        "source" : "1550",
        "target" : "557",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "rain (interacts with) frigid",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "rain (interacts with) frigid",
        "interaction" : "interacts with",
        "SUID" : 1580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1577",
        "source" : "1550",
        "target" : "551",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "rain (interacts with) chill",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "rain (interacts with) chill",
        "interaction" : "interacts with",
        "SUID" : 1577,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1574",
        "source" : "1550",
        "target" : "545",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "rain (interacts with) Howling",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "rain (interacts with) Howling",
        "interaction" : "interacts with",
        "SUID" : 1574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1571",
        "source" : "1550",
        "target" : "539",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "rain (interacts with) gale",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "rain (interacts with) gale",
        "interaction" : "interacts with",
        "SUID" : 1571,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1568",
        "source" : "1550",
        "target" : "533",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "rain (interacts with) thunder",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "rain (interacts with) thunder",
        "interaction" : "interacts with",
        "SUID" : 1568,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1565",
        "source" : "1550",
        "target" : "527",
        "EdgeBetweenness" : 17.42857142857141,
        "shared_name" : "rain (interacts with) raining",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "rain (interacts with) raining",
        "interaction" : "interacts with",
        "SUID" : 1565,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1562",
        "source" : "1550",
        "target" : "521",
        "EdgeBetweenness" : 17.428571428571406,
        "shared_name" : "rain (interacts with) frightening",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "rain (interacts with) frightening",
        "interaction" : "interacts with",
        "SUID" : 1562,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1559",
        "source" : "1550",
        "target" : "515",
        "EdgeBetweenness" : 17.428571428571406,
        "shared_name" : "rain (interacts with) grey sky",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "rain (interacts with) grey sky",
        "interaction" : "interacts with",
        "SUID" : 1559,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1556",
        "source" : "1550",
        "target" : "509",
        "EdgeBetweenness" : 17.428571428571406,
        "shared_name" : "rain (interacts with) clouds",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "rain (interacts with) clouds",
        "interaction" : "interacts with",
        "SUID" : 1556,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1553",
        "source" : "1550",
        "target" : "503",
        "EdgeBetweenness" : 17.428571428571406,
        "shared_name" : "rain (interacts with) air",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "rain (interacts with) air",
        "interaction" : "interacts with",
        "SUID" : 1553,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1547",
        "source" : "1526",
        "target" : "446",
        "EdgeBetweenness" : 18.353860734356818,
        "shared_name" : "parasite (interacts with) I can feel it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "parasite (interacts with) I can feel it",
        "interaction" : "interacts with",
        "SUID" : 1547,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1544",
        "source" : "1526",
        "target" : "440",
        "EdgeBetweenness" : 18.353860734356818,
        "shared_name" : "parasite (interacts with) gaps of my teeth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "parasite (interacts with) gaps of my teeth",
        "interaction" : "interacts with",
        "SUID" : 1544,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1541",
        "source" : "1526",
        "target" : "434",
        "EdgeBetweenness" : 18.353860734356818,
        "shared_name" : "parasite (interacts with) poke out my nostrils",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "parasite (interacts with) poke out my nostrils",
        "interaction" : "interacts with",
        "SUID" : 1541,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1538",
        "source" : "1526",
        "target" : "428",
        "EdgeBetweenness" : 18.353860734356818,
        "shared_name" : "parasite (interacts with) pushes at my nerves",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "parasite (interacts with) pushes at my nerves",
        "interaction" : "interacts with",
        "SUID" : 1538,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1535",
        "source" : "1526",
        "target" : "422",
        "EdgeBetweenness" : 18.353860734356818,
        "shared_name" : "parasite (interacts with) too big for my body",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "parasite (interacts with) too big for my body",
        "interaction" : "interacts with",
        "SUID" : 1535,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1532",
        "source" : "1526",
        "target" : "416",
        "EdgeBetweenness" : 42.85357994210241,
        "shared_name" : "parasite (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "parasite (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 1532,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1529",
        "source" : "1526",
        "target" : "181",
        "EdgeBetweenness" : 86.67604243583828,
        "shared_name" : "parasite (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "parasite (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1529,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1523",
        "source" : "1436",
        "target" : "575",
        "EdgeBetweenness" : 44.692095409655856,
        "shared_name" : "paranoia (interacts with) rain drop",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "paranoia (interacts with) rain drop",
        "interaction" : "interacts with",
        "SUID" : 1523,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1520",
        "source" : "1436",
        "target" : "569",
        "EdgeBetweenness" : 44.692095409655856,
        "shared_name" : "paranoia (interacts with) quiet",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "paranoia (interacts with) quiet",
        "interaction" : "interacts with",
        "SUID" : 1520,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1517",
        "source" : "1436",
        "target" : "563",
        "EdgeBetweenness" : 44.69209540965587,
        "shared_name" : "paranoia (interacts with) flurry",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "paranoia (interacts with) flurry",
        "interaction" : "interacts with",
        "SUID" : 1517,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1514",
        "source" : "1436",
        "target" : "557",
        "EdgeBetweenness" : 44.69209540965586,
        "shared_name" : "paranoia (interacts with) frigid",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "paranoia (interacts with) frigid",
        "interaction" : "interacts with",
        "SUID" : 1514,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1511",
        "source" : "1436",
        "target" : "551",
        "EdgeBetweenness" : 44.692095409655856,
        "shared_name" : "paranoia (interacts with) chill",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "paranoia (interacts with) chill",
        "interaction" : "interacts with",
        "SUID" : 1511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1508",
        "source" : "1436",
        "target" : "545",
        "EdgeBetweenness" : 44.692095409655856,
        "shared_name" : "paranoia (interacts with) Howling",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "paranoia (interacts with) Howling",
        "interaction" : "interacts with",
        "SUID" : 1508,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1505",
        "source" : "1436",
        "target" : "539",
        "EdgeBetweenness" : 44.692095409655856,
        "shared_name" : "paranoia (interacts with) gale",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "paranoia (interacts with) gale",
        "interaction" : "interacts with",
        "SUID" : 1505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1502",
        "source" : "1436",
        "target" : "533",
        "EdgeBetweenness" : 44.69209540965585,
        "shared_name" : "paranoia (interacts with) thunder",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "paranoia (interacts with) thunder",
        "interaction" : "interacts with",
        "SUID" : 1502,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1499",
        "source" : "1436",
        "target" : "527",
        "EdgeBetweenness" : 44.69209540965584,
        "shared_name" : "paranoia (interacts with) raining",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "paranoia (interacts with) raining",
        "interaction" : "interacts with",
        "SUID" : 1499,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1496",
        "source" : "1436",
        "target" : "521",
        "EdgeBetweenness" : 44.69209540965584,
        "shared_name" : "paranoia (interacts with) frightening",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "paranoia (interacts with) frightening",
        "interaction" : "interacts with",
        "SUID" : 1496,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1493",
        "source" : "1436",
        "target" : "515",
        "EdgeBetweenness" : 44.692095409655835,
        "shared_name" : "paranoia (interacts with) grey sky",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "paranoia (interacts with) grey sky",
        "interaction" : "interacts with",
        "SUID" : 1493,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1490",
        "source" : "1436",
        "target" : "509",
        "EdgeBetweenness" : 44.692095409655835,
        "shared_name" : "paranoia (interacts with) clouds",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "paranoia (interacts with) clouds",
        "interaction" : "interacts with",
        "SUID" : 1490,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1487",
        "source" : "1436",
        "target" : "503",
        "EdgeBetweenness" : 44.692095409655835,
        "shared_name" : "paranoia (interacts with) air",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "paranoia (interacts with) air",
        "interaction" : "interacts with",
        "SUID" : 1487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1484",
        "source" : "1436",
        "target" : "497",
        "EdgeBetweenness" : 36.0143400436881,
        "shared_name" : "paranoia (interacts with) Witnessed.",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "paranoia (interacts with) Witnessed.",
        "interaction" : "interacts with",
        "SUID" : 1484,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1481",
        "source" : "1436",
        "target" : "491",
        "EdgeBetweenness" : 36.01434004368805,
        "shared_name" : "paranoia (interacts with) Never",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "paranoia (interacts with) Never",
        "interaction" : "interacts with",
        "SUID" : 1481,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1478",
        "source" : "1436",
        "target" : "485",
        "EdgeBetweenness" : 36.01434004368805,
        "shared_name" : "paranoia (interacts with) They see it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "paranoia (interacts with) They see it",
        "interaction" : "interacts with",
        "SUID" : 1478,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1475",
        "source" : "1436",
        "target" : "479",
        "EdgeBetweenness" : 36.01434004368806,
        "shared_name" : "paranoia (interacts with) No escaping",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "paranoia (interacts with) No escaping",
        "interaction" : "interacts with",
        "SUID" : 1475,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1472",
        "source" : "1436",
        "target" : "473",
        "EdgeBetweenness" : 36.014340043688065,
        "shared_name" : "paranoia (interacts with) Relentlessly)",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "paranoia (interacts with) Relentlessly)",
        "interaction" : "interacts with",
        "SUID" : 1472,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1469",
        "source" : "1436",
        "target" : "467",
        "EdgeBetweenness" : 36.01434004368807,
        "shared_name" : "paranoia (interacts with) Hunting",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "paranoia (interacts with) Hunting",
        "interaction" : "interacts with",
        "SUID" : 1469,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1466",
        "source" : "1436",
        "target" : "181",
        "EdgeBetweenness" : 222.18066112599448,
        "shared_name" : "paranoia (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "paranoia (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1466,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1463",
        "source" : "1436",
        "target" : "458",
        "EdgeBetweenness" : 36.01434004368808,
        "shared_name" : "paranoia (interacts with) The eyes",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "paranoia (interacts with) The eyes",
        "interaction" : "interacts with",
        "SUID" : 1463,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1460",
        "source" : "1436",
        "target" : "452",
        "EdgeBetweenness" : 36.01434004368808,
        "shared_name" : "paranoia (interacts with) Always watching",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "paranoia (interacts with) Always watching",
        "interaction" : "interacts with",
        "SUID" : 1460,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1457",
        "source" : "1436",
        "target" : "446",
        "EdgeBetweenness" : 40.699473085116196,
        "shared_name" : "paranoia (interacts with) I can feel it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "paranoia (interacts with) I can feel it",
        "interaction" : "interacts with",
        "SUID" : 1457,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1454",
        "source" : "1436",
        "target" : "440",
        "EdgeBetweenness" : 40.699473085116196,
        "shared_name" : "paranoia (interacts with) gaps of my teeth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "paranoia (interacts with) gaps of my teeth",
        "interaction" : "interacts with",
        "SUID" : 1454,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1451",
        "source" : "1436",
        "target" : "434",
        "EdgeBetweenness" : 40.699473085116196,
        "shared_name" : "paranoia (interacts with) poke out my nostrils",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "paranoia (interacts with) poke out my nostrils",
        "interaction" : "interacts with",
        "SUID" : 1451,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1448",
        "source" : "1436",
        "target" : "428",
        "EdgeBetweenness" : 40.699473085116196,
        "shared_name" : "paranoia (interacts with) pushes at my nerves",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "paranoia (interacts with) pushes at my nerves",
        "interaction" : "interacts with",
        "SUID" : 1448,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1445",
        "source" : "1436",
        "target" : "422",
        "EdgeBetweenness" : 40.699473085116196,
        "shared_name" : "paranoia (interacts with) too big for my body",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "paranoia (interacts with) too big for my body",
        "interaction" : "interacts with",
        "SUID" : 1445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1442",
        "source" : "1436",
        "target" : "416",
        "EdgeBetweenness" : 118.42360253533172,
        "shared_name" : "paranoia (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "paranoia (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 1442,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1439",
        "source" : "1436",
        "target" : "181",
        "EdgeBetweenness" : 222.18066112599448,
        "shared_name" : "paranoia (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "paranoia (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1439,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1406",
        "source" : "1298",
        "target" : "245",
        "EdgeBetweenness" : 97.67307331959555,
        "shared_name" : "mental-illness (interacts with) copper",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "mental-illness (interacts with) copper",
        "interaction" : "interacts with",
        "SUID" : 1406,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1403",
        "source" : "1298",
        "target" : "239",
        "EdgeBetweenness" : 97.67307331959555,
        "shared_name" : "mental-illness (interacts with) blowtorch",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "mental-illness (interacts with) blowtorch",
        "interaction" : "interacts with",
        "SUID" : 1403,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1400",
        "source" : "1298",
        "target" : "233",
        "EdgeBetweenness" : 79.94560357336427,
        "shared_name" : "mental-illness (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "mental-illness (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1400,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1397",
        "source" : "1298",
        "target" : "227",
        "EdgeBetweenness" : 97.67307331959559,
        "shared_name" : "mental-illness (interacts with) pay",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "mental-illness (interacts with) pay",
        "interaction" : "interacts with",
        "SUID" : 1397,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1394",
        "source" : "1298",
        "target" : "221",
        "EdgeBetweenness" : 97.67307331959559,
        "shared_name" : "mental-illness (interacts with) thing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "mental-illness (interacts with) thing",
        "interaction" : "interacts with",
        "SUID" : 1394,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1391",
        "source" : "1298",
        "target" : "215",
        "EdgeBetweenness" : 97.67307331959559,
        "shared_name" : "mental-illness (interacts with) searing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "mental-illness (interacts with) searing",
        "interaction" : "interacts with",
        "SUID" : 1391,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1388",
        "source" : "1298",
        "target" : "209",
        "EdgeBetweenness" : 66.93719985044697,
        "shared_name" : "mental-illness (interacts with) redness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "mental-illness (interacts with) redness",
        "interaction" : "interacts with",
        "SUID" : 1388,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1385",
        "source" : "1298",
        "target" : "181",
        "EdgeBetweenness" : 86.23845668269509,
        "shared_name" : "mental-illness (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "mental-illness (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1385,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1382",
        "source" : "1298",
        "target" : "404",
        "EdgeBetweenness" : 84.65365796487447,
        "shared_name" : "mental-illness (interacts with) wrongness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "mental-illness (interacts with) wrongness",
        "interaction" : "interacts with",
        "SUID" : 1382,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1379",
        "source" : "1298",
        "target" : "278",
        "EdgeBetweenness" : 68.21415043985635,
        "shared_name" : "mental-illness (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "mental-illness (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 1379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1376",
        "source" : "1298",
        "target" : "395",
        "EdgeBetweenness" : 84.65365796487447,
        "shared_name" : "mental-illness (interacts with) pallidity",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "mental-illness (interacts with) pallidity",
        "interaction" : "interacts with",
        "SUID" : 1376,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1373",
        "source" : "1298",
        "target" : "389",
        "EdgeBetweenness" : 84.65365796487447,
        "shared_name" : "mental-illness (interacts with) withering",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "mental-illness (interacts with) withering",
        "interaction" : "interacts with",
        "SUID" : 1373,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1370",
        "source" : "1298",
        "target" : "233",
        "EdgeBetweenness" : 79.94560357336427,
        "shared_name" : "mental-illness (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "mental-illness (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1370,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1367",
        "source" : "1298",
        "target" : "380",
        "EdgeBetweenness" : 84.65365796487447,
        "shared_name" : "mental-illness (interacts with) vacancy",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "mental-illness (interacts with) vacancy",
        "interaction" : "interacts with",
        "SUID" : 1367,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1364",
        "source" : "1298",
        "target" : "374",
        "EdgeBetweenness" : 84.65365796487447,
        "shared_name" : "mental-illness (interacts with) void",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "mental-illness (interacts with) void",
        "interaction" : "interacts with",
        "SUID" : 1364,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1361",
        "source" : "1298",
        "target" : "368",
        "EdgeBetweenness" : 84.65365796487447,
        "shared_name" : "mental-illness (interacts with) hollow",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "mental-illness (interacts with) hollow",
        "interaction" : "interacts with",
        "SUID" : 1361,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1358",
        "source" : "1298",
        "target" : "181",
        "EdgeBetweenness" : 86.23845668269509,
        "shared_name" : "mental-illness (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "mental-illness (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1358,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1355",
        "source" : "1298",
        "target" : "497",
        "EdgeBetweenness" : 74.51143932669771,
        "shared_name" : "mental-illness (interacts with) Witnessed.",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "mental-illness (interacts with) Witnessed.",
        "interaction" : "interacts with",
        "SUID" : 1355,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1352",
        "source" : "1298",
        "target" : "491",
        "EdgeBetweenness" : 74.51143932669768,
        "shared_name" : "mental-illness (interacts with) Never",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "mental-illness (interacts with) Never",
        "interaction" : "interacts with",
        "SUID" : 1352,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1349",
        "source" : "1298",
        "target" : "485",
        "EdgeBetweenness" : 74.51143932669767,
        "shared_name" : "mental-illness (interacts with) They see it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "mental-illness (interacts with) They see it",
        "interaction" : "interacts with",
        "SUID" : 1349,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1346",
        "source" : "1298",
        "target" : "479",
        "EdgeBetweenness" : 74.51143932669768,
        "shared_name" : "mental-illness (interacts with) No escaping",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "mental-illness (interacts with) No escaping",
        "interaction" : "interacts with",
        "SUID" : 1346,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1343",
        "source" : "1298",
        "target" : "473",
        "EdgeBetweenness" : 74.51143932669767,
        "shared_name" : "mental-illness (interacts with) Relentlessly)",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "mental-illness (interacts with) Relentlessly)",
        "interaction" : "interacts with",
        "SUID" : 1343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1340",
        "source" : "1298",
        "target" : "467",
        "EdgeBetweenness" : 74.51143932669767,
        "shared_name" : "mental-illness (interacts with) Hunting",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "mental-illness (interacts with) Hunting",
        "interaction" : "interacts with",
        "SUID" : 1340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1337",
        "source" : "1298",
        "target" : "181",
        "EdgeBetweenness" : 86.23845668269509,
        "shared_name" : "mental-illness (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "mental-illness (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1337,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1334",
        "source" : "1298",
        "target" : "458",
        "EdgeBetweenness" : 74.51143932669765,
        "shared_name" : "mental-illness (interacts with) The eyes",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "mental-illness (interacts with) The eyes",
        "interaction" : "interacts with",
        "SUID" : 1334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1331",
        "source" : "1298",
        "target" : "452",
        "EdgeBetweenness" : 74.51143932669765,
        "shared_name" : "mental-illness (interacts with) Always watching",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "mental-illness (interacts with) Always watching",
        "interaction" : "interacts with",
        "SUID" : 1331,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1328",
        "source" : "1298",
        "target" : "416",
        "EdgeBetweenness" : 96.24170977134868,
        "shared_name" : "mental-illness (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "mental-illness (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 1328,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1325",
        "source" : "1298",
        "target" : "662",
        "EdgeBetweenness" : 88.11768134863296,
        "shared_name" : "mental-illness (interacts with) Heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "mental-illness (interacts with) Heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1322",
        "source" : "1298",
        "target" : "304",
        "EdgeBetweenness" : 99.71193433534431,
        "shared_name" : "mental-illness (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "mental-illness (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1322,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1319",
        "source" : "1298",
        "target" : "446",
        "EdgeBetweenness" : 65.55060290965788,
        "shared_name" : "mental-illness (interacts with) I can feel it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "mental-illness (interacts with) I can feel it",
        "interaction" : "interacts with",
        "SUID" : 1319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1316",
        "source" : "1298",
        "target" : "440",
        "EdgeBetweenness" : 65.55060290965788,
        "shared_name" : "mental-illness (interacts with) gaps of my teeth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "mental-illness (interacts with) gaps of my teeth",
        "interaction" : "interacts with",
        "SUID" : 1316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1313",
        "source" : "1298",
        "target" : "434",
        "EdgeBetweenness" : 65.5506029096579,
        "shared_name" : "mental-illness (interacts with) poke out my nostrils",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "mental-illness (interacts with) poke out my nostrils",
        "interaction" : "interacts with",
        "SUID" : 1313,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1310",
        "source" : "1298",
        "target" : "428",
        "EdgeBetweenness" : 65.5506029096579,
        "shared_name" : "mental-illness (interacts with) pushes at my nerves",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "mental-illness (interacts with) pushes at my nerves",
        "interaction" : "interacts with",
        "SUID" : 1310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1307",
        "source" : "1298",
        "target" : "422",
        "EdgeBetweenness" : 65.5506029096579,
        "shared_name" : "mental-illness (interacts with) too big for my body",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "mental-illness (interacts with) too big for my body",
        "interaction" : "interacts with",
        "SUID" : 1307,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1304",
        "source" : "1298",
        "target" : "416",
        "EdgeBetweenness" : 96.24170977134868,
        "shared_name" : "mental-illness (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "mental-illness (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 1304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1301",
        "source" : "1298",
        "target" : "181",
        "EdgeBetweenness" : 86.23845668269509,
        "shared_name" : "mental-illness (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "mental-illness (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1301,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1295",
        "source" : "1244",
        "target" : "296",
        "EdgeBetweenness" : 18.606658678704374,
        "shared_name" : "love (interacts with) germs",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "love (interacts with) germs",
        "interaction" : "interacts with",
        "SUID" : 1295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1292",
        "source" : "1244",
        "target" : "290",
        "EdgeBetweenness" : 18.606658678704374,
        "shared_name" : "love (interacts with) slap",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "love (interacts with) slap",
        "interaction" : "interacts with",
        "SUID" : 1292,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1289",
        "source" : "1244",
        "target" : "284",
        "EdgeBetweenness" : 18.60665867870437,
        "shared_name" : "love (interacts with) growth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "love (interacts with) growth",
        "interaction" : "interacts with",
        "SUID" : 1289,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1286",
        "source" : "1244",
        "target" : "278",
        "EdgeBetweenness" : 25.941152857280784,
        "shared_name" : "love (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "love (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 1286,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1283",
        "source" : "1244",
        "target" : "272",
        "EdgeBetweenness" : 18.606658678704367,
        "shared_name" : "love (interacts with) fuzzing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "love (interacts with) fuzzing",
        "interaction" : "interacts with",
        "SUID" : 1283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1280",
        "source" : "1244",
        "target" : "266",
        "EdgeBetweenness" : 18.606658678704367,
        "shared_name" : "love (interacts with) spores",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "love (interacts with) spores",
        "interaction" : "interacts with",
        "SUID" : 1280,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1277",
        "source" : "1244",
        "target" : "260",
        "EdgeBetweenness" : 18.606658678704367,
        "shared_name" : "love (interacts with) rot",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "love (interacts with) rot",
        "interaction" : "interacts with",
        "SUID" : 1277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1274",
        "source" : "1244",
        "target" : "254",
        "EdgeBetweenness" : 9.62803152715122,
        "shared_name" : "love (interacts with) mold",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "love (interacts with) mold",
        "interaction" : "interacts with",
        "SUID" : 1274,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1271",
        "source" : "1244",
        "target" : "233",
        "EdgeBetweenness" : 63.17203746420197,
        "shared_name" : "love (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "love (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1271,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1268",
        "source" : "1244",
        "target" : "245",
        "EdgeBetweenness" : 18.13462500987562,
        "shared_name" : "love (interacts with) copper",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "love (interacts with) copper",
        "interaction" : "interacts with",
        "SUID" : 1268,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1265",
        "source" : "1244",
        "target" : "239",
        "EdgeBetweenness" : 18.13462500987562,
        "shared_name" : "love (interacts with) blowtorch",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "love (interacts with) blowtorch",
        "interaction" : "interacts with",
        "SUID" : 1265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1262",
        "source" : "1244",
        "target" : "233",
        "EdgeBetweenness" : 63.17203746420197,
        "shared_name" : "love (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "love (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1262,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1259",
        "source" : "1244",
        "target" : "227",
        "EdgeBetweenness" : 18.13462500987563,
        "shared_name" : "love (interacts with) pay",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "love (interacts with) pay",
        "interaction" : "interacts with",
        "SUID" : 1259,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1256",
        "source" : "1244",
        "target" : "221",
        "EdgeBetweenness" : 18.13462500987563,
        "shared_name" : "love (interacts with) thing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "love (interacts with) thing",
        "interaction" : "interacts with",
        "SUID" : 1256,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1253",
        "source" : "1244",
        "target" : "215",
        "EdgeBetweenness" : 18.13462500987563,
        "shared_name" : "love (interacts with) searing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "love (interacts with) searing",
        "interaction" : "interacts with",
        "SUID" : 1253,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1250",
        "source" : "1244",
        "target" : "209",
        "EdgeBetweenness" : 10.921874238465199,
        "shared_name" : "love (interacts with) redness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "love (interacts with) redness",
        "interaction" : "interacts with",
        "SUID" : 1250,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1247",
        "source" : "1244",
        "target" : "181",
        "EdgeBetweenness" : 107.96004804447041,
        "shared_name" : "love (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "love (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1241",
        "source" : "1208",
        "target" : "245",
        "EdgeBetweenness" : 26.65873291538893,
        "shared_name" : "loss (interacts with) copper",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "loss (interacts with) copper",
        "interaction" : "interacts with",
        "SUID" : 1241,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1238",
        "source" : "1208",
        "target" : "239",
        "EdgeBetweenness" : 26.65873291538893,
        "shared_name" : "loss (interacts with) blowtorch",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "loss (interacts with) blowtorch",
        "interaction" : "interacts with",
        "SUID" : 1238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1235",
        "source" : "1208",
        "target" : "233",
        "EdgeBetweenness" : 51.69269975566795,
        "shared_name" : "loss (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "loss (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1232",
        "source" : "1208",
        "target" : "227",
        "EdgeBetweenness" : 26.658732915388914,
        "shared_name" : "loss (interacts with) pay",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "loss (interacts with) pay",
        "interaction" : "interacts with",
        "SUID" : 1232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1229",
        "source" : "1208",
        "target" : "221",
        "EdgeBetweenness" : 26.658732915388917,
        "shared_name" : "loss (interacts with) thing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "loss (interacts with) thing",
        "interaction" : "interacts with",
        "SUID" : 1229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1226",
        "source" : "1208",
        "target" : "215",
        "EdgeBetweenness" : 26.658732915388917,
        "shared_name" : "loss (interacts with) searing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "loss (interacts with) searing",
        "interaction" : "interacts with",
        "SUID" : 1226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1223",
        "source" : "1208",
        "target" : "209",
        "EdgeBetweenness" : 17.43219207105356,
        "shared_name" : "loss (interacts with) redness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "loss (interacts with) redness",
        "interaction" : "interacts with",
        "SUID" : 1223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1220",
        "source" : "1208",
        "target" : "181",
        "EdgeBetweenness" : 70.55669178875293,
        "shared_name" : "loss (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "loss (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1217",
        "source" : "1208",
        "target" : "416",
        "EdgeBetweenness" : 64.72803599926152,
        "shared_name" : "loss (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "loss (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 1217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1214",
        "source" : "1208",
        "target" : "662",
        "EdgeBetweenness" : 40.65672900716327,
        "shared_name" : "loss (interacts with) Heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "loss (interacts with) Heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1211",
        "source" : "1208",
        "target" : "304",
        "EdgeBetweenness" : 55.90871778201693,
        "shared_name" : "loss (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "loss (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1205",
        "source" : "1166",
        "target" : "446",
        "EdgeBetweenness" : 23.874437127615174,
        "shared_name" : "isolation (interacts with) I can feel it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "isolation (interacts with) I can feel it",
        "interaction" : "interacts with",
        "SUID" : 1205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1202",
        "source" : "1166",
        "target" : "440",
        "EdgeBetweenness" : 23.874437127615174,
        "shared_name" : "isolation (interacts with) gaps of my teeth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "isolation (interacts with) gaps of my teeth",
        "interaction" : "interacts with",
        "SUID" : 1202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1199",
        "source" : "1166",
        "target" : "434",
        "EdgeBetweenness" : 23.874437127615174,
        "shared_name" : "isolation (interacts with) poke out my nostrils",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "isolation (interacts with) poke out my nostrils",
        "interaction" : "interacts with",
        "SUID" : 1199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1196",
        "source" : "1166",
        "target" : "428",
        "EdgeBetweenness" : 23.87443712761517,
        "shared_name" : "isolation (interacts with) pushes at my nerves",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "isolation (interacts with) pushes at my nerves",
        "interaction" : "interacts with",
        "SUID" : 1196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1193",
        "source" : "1166",
        "target" : "422",
        "EdgeBetweenness" : 23.874437127615174,
        "shared_name" : "isolation (interacts with) too big for my body",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "isolation (interacts with) too big for my body",
        "interaction" : "interacts with",
        "SUID" : 1193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1190",
        "source" : "1166",
        "target" : "416",
        "EdgeBetweenness" : 38.08467130605757,
        "shared_name" : "isolation (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "isolation (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 1190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1187",
        "source" : "1166",
        "target" : "181",
        "EdgeBetweenness" : 70.65421007919916,
        "shared_name" : "isolation (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "isolation (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1184",
        "source" : "1166",
        "target" : "181",
        "EdgeBetweenness" : 70.65421007919916,
        "shared_name" : "isolation (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "isolation (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1184,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1181",
        "source" : "1166",
        "target" : "326",
        "EdgeBetweenness" : 32.82391709422244,
        "shared_name" : "isolation (interacts with) alight in tremors",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "isolation (interacts with) alight in tremors",
        "interaction" : "interacts with",
        "SUID" : 1181,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1178",
        "source" : "1166",
        "target" : "320",
        "EdgeBetweenness" : 32.82391709422244,
        "shared_name" : "isolation (interacts with) greying stains",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "isolation (interacts with) greying stains",
        "interaction" : "interacts with",
        "SUID" : 1178,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1175",
        "source" : "1166",
        "target" : "314",
        "EdgeBetweenness" : 32.82391709422244,
        "shared_name" : "isolation (interacts with) spiraling grain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "isolation (interacts with) spiraling grain",
        "interaction" : "interacts with",
        "SUID" : 1175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1172",
        "source" : "1166",
        "target" : "233",
        "EdgeBetweenness" : 70.47900111623821,
        "shared_name" : "isolation (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "isolation (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1172,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1169",
        "source" : "1166",
        "target" : "304",
        "EdgeBetweenness" : 38.39335408400394,
        "shared_name" : "isolation (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "isolation (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1169,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1163",
        "source" : "1154",
        "target" : "416",
        "EdgeBetweenness" : 79.55990066156147,
        "shared_name" : "injury (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "injury (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 1163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1160",
        "source" : "1154",
        "target" : "662",
        "EdgeBetweenness" : 36.70439848536942,
        "shared_name" : "injury (interacts with) Heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "injury (interacts with) Heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1160,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1157",
        "source" : "1154",
        "target" : "304",
        "EdgeBetweenness" : 66.53656665393491,
        "shared_name" : "injury (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "injury (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1151",
        "source" : "1130",
        "target" : "446",
        "EdgeBetweenness" : 18.353860734356807,
        "shared_name" : "imposter-syndrome (interacts with) I can feel it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "imposter-syndrome (interacts with) I can feel it",
        "interaction" : "interacts with",
        "SUID" : 1151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1148",
        "source" : "1130",
        "target" : "440",
        "EdgeBetweenness" : 18.353860734356807,
        "shared_name" : "imposter-syndrome (interacts with) gaps of my teeth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "imposter-syndrome (interacts with) gaps of my teeth",
        "interaction" : "interacts with",
        "SUID" : 1148,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1145",
        "source" : "1130",
        "target" : "434",
        "EdgeBetweenness" : 18.353860734356807,
        "shared_name" : "imposter-syndrome (interacts with) poke out my nostrils",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "imposter-syndrome (interacts with) poke out my nostrils",
        "interaction" : "interacts with",
        "SUID" : 1145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1142",
        "source" : "1130",
        "target" : "428",
        "EdgeBetweenness" : 18.353860734356807,
        "shared_name" : "imposter-syndrome (interacts with) pushes at my nerves",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "imposter-syndrome (interacts with) pushes at my nerves",
        "interaction" : "interacts with",
        "SUID" : 1142,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1139",
        "source" : "1130",
        "target" : "422",
        "EdgeBetweenness" : 18.353860734356807,
        "shared_name" : "imposter-syndrome (interacts with) too big for my body",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "imposter-syndrome (interacts with) too big for my body",
        "interaction" : "interacts with",
        "SUID" : 1139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1136",
        "source" : "1130",
        "target" : "416",
        "EdgeBetweenness" : 42.853579942102414,
        "shared_name" : "imposter-syndrome (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "imposter-syndrome (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 1136,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1133",
        "source" : "1130",
        "target" : "181",
        "EdgeBetweenness" : 86.6760424358383,
        "shared_name" : "imposter-syndrome (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "imposter-syndrome (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1133,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1127",
        "source" : "1070",
        "target" : "575",
        "EdgeBetweenness" : 45.315153388918425,
        "shared_name" : "imagery (interacts with) rain drop",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "imagery (interacts with) rain drop",
        "interaction" : "interacts with",
        "SUID" : 1127,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1124",
        "source" : "1070",
        "target" : "569",
        "EdgeBetweenness" : 45.315153388918425,
        "shared_name" : "imagery (interacts with) quiet",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "imagery (interacts with) quiet",
        "interaction" : "interacts with",
        "SUID" : 1124,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1121",
        "source" : "1070",
        "target" : "563",
        "EdgeBetweenness" : 45.31515338891844,
        "shared_name" : "imagery (interacts with) flurry",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "imagery (interacts with) flurry",
        "interaction" : "interacts with",
        "SUID" : 1121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1118",
        "source" : "1070",
        "target" : "557",
        "EdgeBetweenness" : 45.315153388918425,
        "shared_name" : "imagery (interacts with) frigid",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "imagery (interacts with) frigid",
        "interaction" : "interacts with",
        "SUID" : 1118,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1115",
        "source" : "1070",
        "target" : "551",
        "EdgeBetweenness" : 45.31515338891844,
        "shared_name" : "imagery (interacts with) chill",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "imagery (interacts with) chill",
        "interaction" : "interacts with",
        "SUID" : 1115,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1112",
        "source" : "1070",
        "target" : "545",
        "EdgeBetweenness" : 45.31515338891844,
        "shared_name" : "imagery (interacts with) Howling",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "imagery (interacts with) Howling",
        "interaction" : "interacts with",
        "SUID" : 1112,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1109",
        "source" : "1070",
        "target" : "539",
        "EdgeBetweenness" : 45.31515338891844,
        "shared_name" : "imagery (interacts with) gale",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "imagery (interacts with) gale",
        "interaction" : "interacts with",
        "SUID" : 1109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1106",
        "source" : "1070",
        "target" : "533",
        "EdgeBetweenness" : 45.31515338891844,
        "shared_name" : "imagery (interacts with) thunder",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "imagery (interacts with) thunder",
        "interaction" : "interacts with",
        "SUID" : 1106,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1103",
        "source" : "1070",
        "target" : "527",
        "EdgeBetweenness" : 45.31515338891844,
        "shared_name" : "imagery (interacts with) raining",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "imagery (interacts with) raining",
        "interaction" : "interacts with",
        "SUID" : 1103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1100",
        "source" : "1070",
        "target" : "521",
        "EdgeBetweenness" : 45.31515338891844,
        "shared_name" : "imagery (interacts with) frightening",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "imagery (interacts with) frightening",
        "interaction" : "interacts with",
        "SUID" : 1100,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1097",
        "source" : "1070",
        "target" : "515",
        "EdgeBetweenness" : 45.315153388918425,
        "shared_name" : "imagery (interacts with) grey sky",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "imagery (interacts with) grey sky",
        "interaction" : "interacts with",
        "SUID" : 1097,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1094",
        "source" : "1070",
        "target" : "509",
        "EdgeBetweenness" : 45.315153388918425,
        "shared_name" : "imagery (interacts with) clouds",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "imagery (interacts with) clouds",
        "interaction" : "interacts with",
        "SUID" : 1094,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1091",
        "source" : "1070",
        "target" : "503",
        "EdgeBetweenness" : 45.315153388918425,
        "shared_name" : "imagery (interacts with) air",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "imagery (interacts with) air",
        "interaction" : "interacts with",
        "SUID" : 1091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1088",
        "source" : "1070",
        "target" : "181",
        "EdgeBetweenness" : 206.8983730958326,
        "shared_name" : "imagery (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "imagery (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1088,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1085",
        "source" : "1070",
        "target" : "326",
        "EdgeBetweenness" : 42.52261165199218,
        "shared_name" : "imagery (interacts with) alight in tremors",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "imagery (interacts with) alight in tremors",
        "interaction" : "interacts with",
        "SUID" : 1085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1082",
        "source" : "1070",
        "target" : "320",
        "EdgeBetweenness" : 42.52261165199217,
        "shared_name" : "imagery (interacts with) greying stains",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "imagery (interacts with) greying stains",
        "interaction" : "interacts with",
        "SUID" : 1082,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1079",
        "source" : "1070",
        "target" : "314",
        "EdgeBetweenness" : 42.52261165199217,
        "shared_name" : "imagery (interacts with) spiraling grain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "imagery (interacts with) spiraling grain",
        "interaction" : "interacts with",
        "SUID" : 1079,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1076",
        "source" : "1070",
        "target" : "233",
        "EdgeBetweenness" : 243.4586835773786,
        "shared_name" : "imagery (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "imagery (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1076,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1073",
        "source" : "1070",
        "target" : "304",
        "EdgeBetweenness" : 131.4208582865271,
        "shared_name" : "imagery (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "imagery (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1067",
        "source" : "983",
        "target" : "296",
        "EdgeBetweenness" : 65.4714723499902,
        "shared_name" : "illness (interacts with) germs",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "illness (interacts with) germs",
        "interaction" : "interacts with",
        "SUID" : 1067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1064",
        "source" : "983",
        "target" : "290",
        "EdgeBetweenness" : 65.47147234999018,
        "shared_name" : "illness (interacts with) slap",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "illness (interacts with) slap",
        "interaction" : "interacts with",
        "SUID" : 1064,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1061",
        "source" : "983",
        "target" : "284",
        "EdgeBetweenness" : 65.47147234999018,
        "shared_name" : "illness (interacts with) growth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "illness (interacts with) growth",
        "interaction" : "interacts with",
        "SUID" : 1061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1058",
        "source" : "983",
        "target" : "278",
        "EdgeBetweenness" : 40.80566723093475,
        "shared_name" : "illness (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "illness (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 1058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1055",
        "source" : "983",
        "target" : "272",
        "EdgeBetweenness" : 65.47147234999017,
        "shared_name" : "illness (interacts with) fuzzing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "illness (interacts with) fuzzing",
        "interaction" : "interacts with",
        "SUID" : 1055,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1052",
        "source" : "983",
        "target" : "266",
        "EdgeBetweenness" : 65.47147234999015,
        "shared_name" : "illness (interacts with) spores",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "illness (interacts with) spores",
        "interaction" : "interacts with",
        "SUID" : 1052,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1049",
        "source" : "983",
        "target" : "260",
        "EdgeBetweenness" : 65.47147234999015,
        "shared_name" : "illness (interacts with) rot",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "illness (interacts with) rot",
        "interaction" : "interacts with",
        "SUID" : 1049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1046",
        "source" : "983",
        "target" : "254",
        "EdgeBetweenness" : 44.86902988688242,
        "shared_name" : "illness (interacts with) mold",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "illness (interacts with) mold",
        "interaction" : "interacts with",
        "SUID" : 1046,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1043",
        "source" : "983",
        "target" : "233",
        "EdgeBetweenness" : 66.60256059884848,
        "shared_name" : "illness (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "illness (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1040",
        "source" : "983",
        "target" : "404",
        "EdgeBetweenness" : 54.63095541176583,
        "shared_name" : "illness (interacts with) wrongness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "illness (interacts with) wrongness",
        "interaction" : "interacts with",
        "SUID" : 1040,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1037",
        "source" : "983",
        "target" : "278",
        "EdgeBetweenness" : 40.80566723093475,
        "shared_name" : "illness (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "illness (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 1037,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1034",
        "source" : "983",
        "target" : "395",
        "EdgeBetweenness" : 54.630955411765825,
        "shared_name" : "illness (interacts with) pallidity",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "illness (interacts with) pallidity",
        "interaction" : "interacts with",
        "SUID" : 1034,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1031",
        "source" : "983",
        "target" : "389",
        "EdgeBetweenness" : 54.630955411765825,
        "shared_name" : "illness (interacts with) withering",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "illness (interacts with) withering",
        "interaction" : "interacts with",
        "SUID" : 1031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1028",
        "source" : "983",
        "target" : "233",
        "EdgeBetweenness" : 66.60256059884848,
        "shared_name" : "illness (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "illness (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1028,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1025",
        "source" : "983",
        "target" : "380",
        "EdgeBetweenness" : 54.630955411765825,
        "shared_name" : "illness (interacts with) vacancy",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "illness (interacts with) vacancy",
        "interaction" : "interacts with",
        "SUID" : 1025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1022",
        "source" : "983",
        "target" : "374",
        "EdgeBetweenness" : 54.630955411765825,
        "shared_name" : "illness (interacts with) void",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "illness (interacts with) void",
        "interaction" : "interacts with",
        "SUID" : 1022,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1019",
        "source" : "983",
        "target" : "368",
        "EdgeBetweenness" : 54.630955411765825,
        "shared_name" : "illness (interacts with) hollow",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "illness (interacts with) hollow",
        "interaction" : "interacts with",
        "SUID" : 1019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1016",
        "source" : "983",
        "target" : "181",
        "EdgeBetweenness" : 91.31263033117746,
        "shared_name" : "illness (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "illness (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1016,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1013",
        "source" : "983",
        "target" : "416",
        "EdgeBetweenness" : 89.62094126788041,
        "shared_name" : "illness (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "illness (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 1013,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1010",
        "source" : "983",
        "target" : "662",
        "EdgeBetweenness" : 68.7479984063433,
        "shared_name" : "illness (interacts with) Heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "illness (interacts with) Heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1010,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1007",
        "source" : "983",
        "target" : "304",
        "EdgeBetweenness" : 86.7487633280984,
        "shared_name" : "illness (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "illness (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 1007,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1004",
        "source" : "983",
        "target" : "446",
        "EdgeBetweenness" : 67.8018003943445,
        "shared_name" : "illness (interacts with) I can feel it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "illness (interacts with) I can feel it",
        "interaction" : "interacts with",
        "SUID" : 1004,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1001",
        "source" : "983",
        "target" : "440",
        "EdgeBetweenness" : 67.8018003943445,
        "shared_name" : "illness (interacts with) gaps of my teeth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "illness (interacts with) gaps of my teeth",
        "interaction" : "interacts with",
        "SUID" : 1001,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "998",
        "source" : "983",
        "target" : "434",
        "EdgeBetweenness" : 67.8018003943445,
        "shared_name" : "illness (interacts with) poke out my nostrils",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "illness (interacts with) poke out my nostrils",
        "interaction" : "interacts with",
        "SUID" : 998,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "995",
        "source" : "983",
        "target" : "428",
        "EdgeBetweenness" : 67.8018003943445,
        "shared_name" : "illness (interacts with) pushes at my nerves",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "illness (interacts with) pushes at my nerves",
        "interaction" : "interacts with",
        "SUID" : 995,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "992",
        "source" : "983",
        "target" : "422",
        "EdgeBetweenness" : 67.8018003943445,
        "shared_name" : "illness (interacts with) too big for my body",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "illness (interacts with) too big for my body",
        "interaction" : "interacts with",
        "SUID" : 992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "989",
        "source" : "983",
        "target" : "416",
        "EdgeBetweenness" : 89.62094126788041,
        "shared_name" : "illness (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "illness (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "986",
        "source" : "983",
        "target" : "181",
        "EdgeBetweenness" : 91.31263033117746,
        "shared_name" : "illness (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "illness (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 986,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "980",
        "source" : "953",
        "target" : "404",
        "EdgeBetweenness" : 14.496111431395454,
        "shared_name" : "hunger (interacts with) wrongness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "hunger (interacts with) wrongness",
        "interaction" : "interacts with",
        "SUID" : 980,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "977",
        "source" : "953",
        "target" : "278",
        "EdgeBetweenness" : 24.657941267546377,
        "shared_name" : "hunger (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "hunger (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 977,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "974",
        "source" : "953",
        "target" : "395",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "hunger (interacts with) pallidity",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "hunger (interacts with) pallidity",
        "interaction" : "interacts with",
        "SUID" : 974,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "971",
        "source" : "953",
        "target" : "389",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "hunger (interacts with) withering",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "hunger (interacts with) withering",
        "interaction" : "interacts with",
        "SUID" : 971,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "968",
        "source" : "953",
        "target" : "233",
        "EdgeBetweenness" : 62.509063869301514,
        "shared_name" : "hunger (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "hunger (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 968,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "965",
        "source" : "953",
        "target" : "380",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "hunger (interacts with) vacancy",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "hunger (interacts with) vacancy",
        "interaction" : "interacts with",
        "SUID" : 965,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "962",
        "source" : "953",
        "target" : "374",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "hunger (interacts with) void",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "hunger (interacts with) void",
        "interaction" : "interacts with",
        "SUID" : 962,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "959",
        "source" : "953",
        "target" : "368",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "hunger (interacts with) hollow",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "hunger (interacts with) hollow",
        "interaction" : "interacts with",
        "SUID" : 959,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "956",
        "source" : "953",
        "target" : "181",
        "EdgeBetweenness" : 95.00774225299043,
        "shared_name" : "hunger (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "hunger (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 956,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "941",
        "source" : "932",
        "target" : "416",
        "EdgeBetweenness" : 79.55990066156141,
        "shared_name" : "heart (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "heart (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "938",
        "source" : "932",
        "target" : "662",
        "EdgeBetweenness" : 36.70439848536943,
        "shared_name" : "heart (interacts with) Heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "heart (interacts with) Heartbeat",
        "interaction" : "interacts with",
        "SUID" : 938,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "935",
        "source" : "932",
        "target" : "304",
        "EdgeBetweenness" : 66.53656665393488,
        "shared_name" : "heart (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "heart (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 935,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "929",
        "source" : "920",
        "target" : "416",
        "EdgeBetweenness" : 79.55990066156144,
        "shared_name" : "health (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "health (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 929,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "926",
        "source" : "920",
        "target" : "662",
        "EdgeBetweenness" : 36.704398485369424,
        "shared_name" : "health (interacts with) Heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "health (interacts with) Heartbeat",
        "interaction" : "interacts with",
        "SUID" : 926,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "923",
        "source" : "920",
        "target" : "304",
        "EdgeBetweenness" : 66.53656665393488,
        "shared_name" : "health (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "health (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 923,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "917",
        "source" : "908",
        "target" : "416",
        "EdgeBetweenness" : 79.55990066156146,
        "shared_name" : "grief (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "grief (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "914",
        "source" : "908",
        "target" : "662",
        "EdgeBetweenness" : 36.70439848536942,
        "shared_name" : "grief (interacts with) Heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "grief (interacts with) Heartbeat",
        "interaction" : "interacts with",
        "SUID" : 914,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "911",
        "source" : "908",
        "target" : "304",
        "EdgeBetweenness" : 66.5365666539349,
        "shared_name" : "grief (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "grief (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 911,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "905",
        "source" : "800",
        "target" : "575",
        "EdgeBetweenness" : 71.14876964460416,
        "shared_name" : "fear (interacts with) rain drop",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "fear (interacts with) rain drop",
        "interaction" : "interacts with",
        "SUID" : 905,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "902",
        "source" : "800",
        "target" : "569",
        "EdgeBetweenness" : 71.14876964460414,
        "shared_name" : "fear (interacts with) quiet",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "fear (interacts with) quiet",
        "interaction" : "interacts with",
        "SUID" : 902,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "899",
        "source" : "800",
        "target" : "563",
        "EdgeBetweenness" : 71.14876964460416,
        "shared_name" : "fear (interacts with) flurry",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "fear (interacts with) flurry",
        "interaction" : "interacts with",
        "SUID" : 899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "896",
        "source" : "800",
        "target" : "557",
        "EdgeBetweenness" : 71.14876964460414,
        "shared_name" : "fear (interacts with) frigid",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "fear (interacts with) frigid",
        "interaction" : "interacts with",
        "SUID" : 896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "893",
        "source" : "800",
        "target" : "551",
        "EdgeBetweenness" : 71.14876964460414,
        "shared_name" : "fear (interacts with) chill",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "fear (interacts with) chill",
        "interaction" : "interacts with",
        "SUID" : 893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "890",
        "source" : "800",
        "target" : "545",
        "EdgeBetweenness" : 71.14876964460413,
        "shared_name" : "fear (interacts with) Howling",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "fear (interacts with) Howling",
        "interaction" : "interacts with",
        "SUID" : 890,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "887",
        "source" : "800",
        "target" : "539",
        "EdgeBetweenness" : 71.14876964460414,
        "shared_name" : "fear (interacts with) gale",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "fear (interacts with) gale",
        "interaction" : "interacts with",
        "SUID" : 887,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "884",
        "source" : "800",
        "target" : "533",
        "EdgeBetweenness" : 71.14876964460414,
        "shared_name" : "fear (interacts with) thunder",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "fear (interacts with) thunder",
        "interaction" : "interacts with",
        "SUID" : 884,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "881",
        "source" : "800",
        "target" : "527",
        "EdgeBetweenness" : 71.14876964460414,
        "shared_name" : "fear (interacts with) raining",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "fear (interacts with) raining",
        "interaction" : "interacts with",
        "SUID" : 881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "878",
        "source" : "800",
        "target" : "521",
        "EdgeBetweenness" : 71.14876964460414,
        "shared_name" : "fear (interacts with) frightening",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "fear (interacts with) frightening",
        "interaction" : "interacts with",
        "SUID" : 878,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "875",
        "source" : "800",
        "target" : "515",
        "EdgeBetweenness" : 71.14876964460414,
        "shared_name" : "fear (interacts with) grey sky",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "fear (interacts with) grey sky",
        "interaction" : "interacts with",
        "SUID" : 875,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "872",
        "source" : "800",
        "target" : "509",
        "EdgeBetweenness" : 71.14876964460414,
        "shared_name" : "fear (interacts with) clouds",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "fear (interacts with) clouds",
        "interaction" : "interacts with",
        "SUID" : 872,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "869",
        "source" : "800",
        "target" : "503",
        "EdgeBetweenness" : 71.14876964460414,
        "shared_name" : "fear (interacts with) air",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "fear (interacts with) air",
        "interaction" : "interacts with",
        "SUID" : 869,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "866",
        "source" : "800",
        "target" : "497",
        "EdgeBetweenness" : 49.95741463309587,
        "shared_name" : "fear (interacts with) Witnessed.",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "fear (interacts with) Witnessed.",
        "interaction" : "interacts with",
        "SUID" : 866,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "863",
        "source" : "800",
        "target" : "491",
        "EdgeBetweenness" : 49.95741463309585,
        "shared_name" : "fear (interacts with) Never",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "fear (interacts with) Never",
        "interaction" : "interacts with",
        "SUID" : 863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "860",
        "source" : "800",
        "target" : "485",
        "EdgeBetweenness" : 49.95741463309586,
        "shared_name" : "fear (interacts with) They see it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "fear (interacts with) They see it",
        "interaction" : "interacts with",
        "SUID" : 860,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "857",
        "source" : "800",
        "target" : "479",
        "EdgeBetweenness" : 49.957414633095865,
        "shared_name" : "fear (interacts with) No escaping",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "fear (interacts with) No escaping",
        "interaction" : "interacts with",
        "SUID" : 857,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "854",
        "source" : "800",
        "target" : "473",
        "EdgeBetweenness" : 49.957414633095865,
        "shared_name" : "fear (interacts with) Relentlessly)",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "fear (interacts with) Relentlessly)",
        "interaction" : "interacts with",
        "SUID" : 854,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "851",
        "source" : "800",
        "target" : "467",
        "EdgeBetweenness" : 49.95741463309587,
        "shared_name" : "fear (interacts with) Hunting",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "fear (interacts with) Hunting",
        "interaction" : "interacts with",
        "SUID" : 851,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "848",
        "source" : "800",
        "target" : "181",
        "EdgeBetweenness" : 216.7649857821465,
        "shared_name" : "fear (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "fear (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 848,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "845",
        "source" : "800",
        "target" : "458",
        "EdgeBetweenness" : 49.95741463309587,
        "shared_name" : "fear (interacts with) The eyes",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "fear (interacts with) The eyes",
        "interaction" : "interacts with",
        "SUID" : 845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "842",
        "source" : "800",
        "target" : "452",
        "EdgeBetweenness" : 49.95741463309587,
        "shared_name" : "fear (interacts with) Always watching",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "fear (interacts with) Always watching",
        "interaction" : "interacts with",
        "SUID" : 842,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "839",
        "source" : "800",
        "target" : "446",
        "EdgeBetweenness" : 49.254190255875365,
        "shared_name" : "fear (interacts with) I can feel it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "fear (interacts with) I can feel it",
        "interaction" : "interacts with",
        "SUID" : 839,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "836",
        "source" : "800",
        "target" : "440",
        "EdgeBetweenness" : 49.25419025587537,
        "shared_name" : "fear (interacts with) gaps of my teeth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "fear (interacts with) gaps of my teeth",
        "interaction" : "interacts with",
        "SUID" : 836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "833",
        "source" : "800",
        "target" : "434",
        "EdgeBetweenness" : 49.25419025587537,
        "shared_name" : "fear (interacts with) poke out my nostrils",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "fear (interacts with) poke out my nostrils",
        "interaction" : "interacts with",
        "SUID" : 833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "830",
        "source" : "800",
        "target" : "428",
        "EdgeBetweenness" : 49.25419025587537,
        "shared_name" : "fear (interacts with) pushes at my nerves",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "fear (interacts with) pushes at my nerves",
        "interaction" : "interacts with",
        "SUID" : 830,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "827",
        "source" : "800",
        "target" : "422",
        "EdgeBetweenness" : 49.254190255875365,
        "shared_name" : "fear (interacts with) too big for my body",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "fear (interacts with) too big for my body",
        "interaction" : "interacts with",
        "SUID" : 827,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "824",
        "source" : "800",
        "target" : "416",
        "EdgeBetweenness" : 118.37150648895101,
        "shared_name" : "fear (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "fear (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 824,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "821",
        "source" : "800",
        "target" : "181",
        "EdgeBetweenness" : 216.7649857821465,
        "shared_name" : "fear (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "fear (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 821,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "818",
        "source" : "800",
        "target" : "181",
        "EdgeBetweenness" : 216.7649857821465,
        "shared_name" : "fear (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "fear (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 818,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "815",
        "source" : "800",
        "target" : "326",
        "EdgeBetweenness" : 79.88788149982196,
        "shared_name" : "fear (interacts with) alight in tremors",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "fear (interacts with) alight in tremors",
        "interaction" : "interacts with",
        "SUID" : 815,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "812",
        "source" : "800",
        "target" : "320",
        "EdgeBetweenness" : 79.88788149982199,
        "shared_name" : "fear (interacts with) greying stains",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "fear (interacts with) greying stains",
        "interaction" : "interacts with",
        "SUID" : 812,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "809",
        "source" : "800",
        "target" : "314",
        "EdgeBetweenness" : 79.88788149982199,
        "shared_name" : "fear (interacts with) spiraling grain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "fear (interacts with) spiraling grain",
        "interaction" : "interacts with",
        "SUID" : 809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "806",
        "source" : "800",
        "target" : "233",
        "EdgeBetweenness" : 268.66018824532034,
        "shared_name" : "fear (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "fear (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 806,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "803",
        "source" : "800",
        "target" : "304",
        "EdgeBetweenness" : 147.37999284372273,
        "shared_name" : "fear (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "fear (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "797",
        "source" : "770",
        "target" : "497",
        "EdgeBetweenness" : 16.62717704776513,
        "shared_name" : "eyes (interacts with) Witnessed.",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "eyes (interacts with) Witnessed.",
        "interaction" : "interacts with",
        "SUID" : 797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "794",
        "source" : "770",
        "target" : "491",
        "EdgeBetweenness" : 16.62717704776512,
        "shared_name" : "eyes (interacts with) Never",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "eyes (interacts with) Never",
        "interaction" : "interacts with",
        "SUID" : 794,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "791",
        "source" : "770",
        "target" : "485",
        "EdgeBetweenness" : 16.627177047765123,
        "shared_name" : "eyes (interacts with) They see it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "eyes (interacts with) They see it",
        "interaction" : "interacts with",
        "SUID" : 791,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "788",
        "source" : "770",
        "target" : "479",
        "EdgeBetweenness" : 16.627177047765127,
        "shared_name" : "eyes (interacts with) No escaping",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "eyes (interacts with) No escaping",
        "interaction" : "interacts with",
        "SUID" : 788,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "785",
        "source" : "770",
        "target" : "473",
        "EdgeBetweenness" : 16.627177047765127,
        "shared_name" : "eyes (interacts with) Relentlessly)",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "eyes (interacts with) Relentlessly)",
        "interaction" : "interacts with",
        "SUID" : 785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "782",
        "source" : "770",
        "target" : "467",
        "EdgeBetweenness" : 16.627177047765127,
        "shared_name" : "eyes (interacts with) Hunting",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "eyes (interacts with) Hunting",
        "interaction" : "interacts with",
        "SUID" : 782,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "779",
        "source" : "770",
        "target" : "181",
        "EdgeBetweenness" : 101.27195596816335,
        "shared_name" : "eyes (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "eyes (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "776",
        "source" : "770",
        "target" : "458",
        "EdgeBetweenness" : 16.627177047765127,
        "shared_name" : "eyes (interacts with) The eyes",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "eyes (interacts with) The eyes",
        "interaction" : "interacts with",
        "SUID" : 776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "773",
        "source" : "770",
        "target" : "452",
        "EdgeBetweenness" : 16.627177047765127,
        "shared_name" : "eyes (interacts with) Always watching",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "eyes (interacts with) Always watching",
        "interaction" : "interacts with",
        "SUID" : 773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "source" : "740",
        "target" : "404",
        "EdgeBetweenness" : 14.496111431395452,
        "shared_name" : "empty (interacts with) wrongness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "empty (interacts with) wrongness",
        "interaction" : "interacts with",
        "SUID" : 767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "764",
        "source" : "740",
        "target" : "278",
        "EdgeBetweenness" : 24.65794126754637,
        "shared_name" : "empty (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "empty (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "761",
        "source" : "740",
        "target" : "395",
        "EdgeBetweenness" : 14.496111431395452,
        "shared_name" : "empty (interacts with) pallidity",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "empty (interacts with) pallidity",
        "interaction" : "interacts with",
        "SUID" : 761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "758",
        "source" : "740",
        "target" : "389",
        "EdgeBetweenness" : 14.496111431395452,
        "shared_name" : "empty (interacts with) withering",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "empty (interacts with) withering",
        "interaction" : "interacts with",
        "SUID" : 758,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "755",
        "source" : "740",
        "target" : "233",
        "EdgeBetweenness" : 62.50906386930152,
        "shared_name" : "empty (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "empty (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "752",
        "source" : "740",
        "target" : "380",
        "EdgeBetweenness" : 14.496111431395452,
        "shared_name" : "empty (interacts with) vacancy",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "empty (interacts with) vacancy",
        "interaction" : "interacts with",
        "SUID" : 752,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "749",
        "source" : "740",
        "target" : "374",
        "EdgeBetweenness" : 14.496111431395452,
        "shared_name" : "empty (interacts with) void",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "empty (interacts with) void",
        "interaction" : "interacts with",
        "SUID" : 749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "746",
        "source" : "740",
        "target" : "368",
        "EdgeBetweenness" : 14.496111431395452,
        "shared_name" : "empty (interacts with) hollow",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "empty (interacts with) hollow",
        "interaction" : "interacts with",
        "SUID" : 746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "743",
        "source" : "740",
        "target" : "181",
        "EdgeBetweenness" : 95.00774225299041,
        "shared_name" : "empty (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "empty (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "737",
        "source" : "710",
        "target" : "404",
        "EdgeBetweenness" : 14.496111431395454,
        "shared_name" : "eating-disorder (interacts with) wrongness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "eating-disorder (interacts with) wrongness",
        "interaction" : "interacts with",
        "SUID" : 737,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "734",
        "source" : "710",
        "target" : "278",
        "EdgeBetweenness" : 24.65794126754637,
        "shared_name" : "eating-disorder (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "eating-disorder (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "731",
        "source" : "710",
        "target" : "395",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "eating-disorder (interacts with) pallidity",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "eating-disorder (interacts with) pallidity",
        "interaction" : "interacts with",
        "SUID" : 731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "728",
        "source" : "710",
        "target" : "389",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "eating-disorder (interacts with) withering",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "eating-disorder (interacts with) withering",
        "interaction" : "interacts with",
        "SUID" : 728,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "725",
        "source" : "710",
        "target" : "233",
        "EdgeBetweenness" : 62.50906386930152,
        "shared_name" : "eating-disorder (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "eating-disorder (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "722",
        "source" : "710",
        "target" : "380",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "eating-disorder (interacts with) vacancy",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "eating-disorder (interacts with) vacancy",
        "interaction" : "interacts with",
        "SUID" : 722,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "719",
        "source" : "710",
        "target" : "374",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "eating-disorder (interacts with) void",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "eating-disorder (interacts with) void",
        "interaction" : "interacts with",
        "SUID" : 719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "716",
        "source" : "710",
        "target" : "368",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "eating-disorder (interacts with) hollow",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "eating-disorder (interacts with) hollow",
        "interaction" : "interacts with",
        "SUID" : 716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "713",
        "source" : "710",
        "target" : "181",
        "EdgeBetweenness" : 95.00774225299041,
        "shared_name" : "eating-disorder (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "eating-disorder (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "707",
        "source" : "671",
        "target" : "404",
        "EdgeBetweenness" : 22.99237302777713,
        "shared_name" : "depression (interacts with) wrongness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "depression (interacts with) wrongness",
        "interaction" : "interacts with",
        "SUID" : 707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "704",
        "source" : "671",
        "target" : "278",
        "EdgeBetweenness" : 30.779150001353205,
        "shared_name" : "depression (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "depression (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 704,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "701",
        "source" : "671",
        "target" : "395",
        "EdgeBetweenness" : 22.99237302777713,
        "shared_name" : "depression (interacts with) pallidity",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "depression (interacts with) pallidity",
        "interaction" : "interacts with",
        "SUID" : 701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "698",
        "source" : "671",
        "target" : "389",
        "EdgeBetweenness" : 22.99237302777713,
        "shared_name" : "depression (interacts with) withering",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "depression (interacts with) withering",
        "interaction" : "interacts with",
        "SUID" : 698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "695",
        "source" : "671",
        "target" : "233",
        "EdgeBetweenness" : 54.404882026929535,
        "shared_name" : "depression (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "depression (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "692",
        "source" : "671",
        "target" : "380",
        "EdgeBetweenness" : 22.99237302777713,
        "shared_name" : "depression (interacts with) vacancy",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "depression (interacts with) vacancy",
        "interaction" : "interacts with",
        "SUID" : 692,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "source" : "671",
        "target" : "374",
        "EdgeBetweenness" : 22.99237302777713,
        "shared_name" : "depression (interacts with) void",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "depression (interacts with) void",
        "interaction" : "interacts with",
        "SUID" : 689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "686",
        "source" : "671",
        "target" : "368",
        "EdgeBetweenness" : 22.99237302777713,
        "shared_name" : "depression (interacts with) hollow",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "depression (interacts with) hollow",
        "interaction" : "interacts with",
        "SUID" : 686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "683",
        "source" : "671",
        "target" : "181",
        "EdgeBetweenness" : 76.0202895138597,
        "shared_name" : "depression (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "depression (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "680",
        "source" : "671",
        "target" : "416",
        "EdgeBetweenness" : 60.506318196885815,
        "shared_name" : "depression (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "depression (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "677",
        "source" : "671",
        "target" : "662",
        "EdgeBetweenness" : 35.21534833554145,
        "shared_name" : "depression (interacts with) Heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "depression (interacts with) Heartbeat",
        "interaction" : "interacts with",
        "SUID" : 677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "674",
        "source" : "671",
        "target" : "304",
        "EdgeBetweenness" : 52.33890633394905,
        "shared_name" : "depression (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "depression (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 674,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "668",
        "source" : "656",
        "target" : "416",
        "EdgeBetweenness" : 79.55990066156144,
        "shared_name" : "death (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "death (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "665",
        "source" : "656",
        "target" : "662",
        "EdgeBetweenness" : 36.704398485369424,
        "shared_name" : "death (interacts with) Heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "death (interacts with) Heartbeat",
        "interaction" : "interacts with",
        "SUID" : 665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "659",
        "source" : "656",
        "target" : "304",
        "EdgeBetweenness" : 66.5365666539349,
        "shared_name" : "death (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "death (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 659,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "653",
        "source" : "629",
        "target" : "245",
        "EdgeBetweenness" : 14.509207831225833,
        "shared_name" : "color (interacts with) copper",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "color (interacts with) copper",
        "interaction" : "interacts with",
        "SUID" : 653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "650",
        "source" : "629",
        "target" : "239",
        "EdgeBetweenness" : 14.509207831225833,
        "shared_name" : "color (interacts with) blowtorch",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "color (interacts with) blowtorch",
        "interaction" : "interacts with",
        "SUID" : 650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "647",
        "source" : "629",
        "target" : "233",
        "EdgeBetweenness" : 62.93533853031964,
        "shared_name" : "color (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "color (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 647,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "644",
        "source" : "629",
        "target" : "227",
        "EdgeBetweenness" : 14.50920783122584,
        "shared_name" : "color (interacts with) pay",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "color (interacts with) pay",
        "interaction" : "interacts with",
        "SUID" : 644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "641",
        "source" : "629",
        "target" : "221",
        "EdgeBetweenness" : 14.50920783122584,
        "shared_name" : "color (interacts with) thing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "color (interacts with) thing",
        "interaction" : "interacts with",
        "SUID" : 641,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "638",
        "source" : "629",
        "target" : "215",
        "EdgeBetweenness" : 14.50920783122584,
        "shared_name" : "color (interacts with) searing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "color (interacts with) searing",
        "interaction" : "interacts with",
        "SUID" : 638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "635",
        "source" : "629",
        "target" : "209",
        "EdgeBetweenness" : 8.612562181007256,
        "shared_name" : "color (interacts with) redness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "color (interacts with) redness",
        "interaction" : "interacts with",
        "SUID" : 635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "632",
        "source" : "629",
        "target" : "181",
        "EdgeBetweenness" : 93.60893077536844,
        "shared_name" : "color (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "color (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "626",
        "source" : "608",
        "target" : "181",
        "EdgeBetweenness" : 85.62491836799356,
        "shared_name" : "clock (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "clock (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "623",
        "source" : "608",
        "target" : "326",
        "EdgeBetweenness" : 24.177509776505456,
        "shared_name" : "clock (interacts with) alight in tremors",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "clock (interacts with) alight in tremors",
        "interaction" : "interacts with",
        "SUID" : 623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "620",
        "source" : "608",
        "target" : "320",
        "EdgeBetweenness" : 24.17750977650546,
        "shared_name" : "clock (interacts with) greying stains",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "clock (interacts with) greying stains",
        "interaction" : "interacts with",
        "SUID" : 620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "617",
        "source" : "608",
        "target" : "314",
        "EdgeBetweenness" : 24.177509776505456,
        "shared_name" : "clock (interacts with) spiraling grain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "clock (interacts with) spiraling grain",
        "interaction" : "interacts with",
        "SUID" : 617,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "614",
        "source" : "608",
        "target" : "233",
        "EdgeBetweenness" : 69.73746359852503,
        "shared_name" : "clock (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "clock (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "611",
        "source" : "608",
        "target" : "304",
        "EdgeBetweenness" : 46.56848100581415,
        "shared_name" : "clock (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "clock (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "605",
        "source" : "581",
        "target" : "245",
        "EdgeBetweenness" : 14.50920783122584,
        "shared_name" : "betrayal (interacts with) copper",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "betrayal (interacts with) copper",
        "interaction" : "interacts with",
        "SUID" : 605,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "602",
        "source" : "581",
        "target" : "239",
        "EdgeBetweenness" : 14.50920783122584,
        "shared_name" : "betrayal (interacts with) blowtorch",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "betrayal (interacts with) blowtorch",
        "interaction" : "interacts with",
        "SUID" : 602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "599",
        "source" : "581",
        "target" : "233",
        "EdgeBetweenness" : 62.93533853031959,
        "shared_name" : "betrayal (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "betrayal (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "596",
        "source" : "581",
        "target" : "227",
        "EdgeBetweenness" : 14.509207831225838,
        "shared_name" : "betrayal (interacts with) pay",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "betrayal (interacts with) pay",
        "interaction" : "interacts with",
        "SUID" : 596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "593",
        "source" : "581",
        "target" : "221",
        "EdgeBetweenness" : 14.50920783122584,
        "shared_name" : "betrayal (interacts with) thing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "betrayal (interacts with) thing",
        "interaction" : "interacts with",
        "SUID" : 593,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "590",
        "source" : "581",
        "target" : "215",
        "EdgeBetweenness" : 14.509207831225838,
        "shared_name" : "betrayal (interacts with) searing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "betrayal (interacts with) searing",
        "interaction" : "interacts with",
        "SUID" : 590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "587",
        "source" : "581",
        "target" : "209",
        "EdgeBetweenness" : 8.612562181007252,
        "shared_name" : "betrayal (interacts with) redness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "betrayal (interacts with) redness",
        "interaction" : "interacts with",
        "SUID" : 587,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "584",
        "source" : "581",
        "target" : "181",
        "EdgeBetweenness" : 93.60893077536839,
        "shared_name" : "betrayal (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "betrayal (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "578",
        "source" : "410",
        "target" : "575",
        "EdgeBetweenness" : 44.692095409655856,
        "shared_name" : "anxiety (interacts with) rain drop",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "anxiety (interacts with) rain drop",
        "interaction" : "interacts with",
        "SUID" : 578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "572",
        "source" : "410",
        "target" : "569",
        "EdgeBetweenness" : 44.692095409655856,
        "shared_name" : "anxiety (interacts with) quiet",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "anxiety (interacts with) quiet",
        "interaction" : "interacts with",
        "SUID" : 572,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "566",
        "source" : "410",
        "target" : "563",
        "EdgeBetweenness" : 44.69209540965587,
        "shared_name" : "anxiety (interacts with) flurry",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "anxiety (interacts with) flurry",
        "interaction" : "interacts with",
        "SUID" : 566,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "560",
        "source" : "410",
        "target" : "557",
        "EdgeBetweenness" : 44.69209540965586,
        "shared_name" : "anxiety (interacts with) frigid",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "anxiety (interacts with) frigid",
        "interaction" : "interacts with",
        "SUID" : 560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "554",
        "source" : "410",
        "target" : "551",
        "EdgeBetweenness" : 44.692095409655856,
        "shared_name" : "anxiety (interacts with) chill",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "anxiety (interacts with) chill",
        "interaction" : "interacts with",
        "SUID" : 554,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "548",
        "source" : "410",
        "target" : "545",
        "EdgeBetweenness" : 44.692095409655856,
        "shared_name" : "anxiety (interacts with) Howling",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "anxiety (interacts with) Howling",
        "interaction" : "interacts with",
        "SUID" : 548,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "542",
        "source" : "410",
        "target" : "539",
        "EdgeBetweenness" : 44.69209540965585,
        "shared_name" : "anxiety (interacts with) gale",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "anxiety (interacts with) gale",
        "interaction" : "interacts with",
        "SUID" : 542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "536",
        "source" : "410",
        "target" : "533",
        "EdgeBetweenness" : 44.69209540965585,
        "shared_name" : "anxiety (interacts with) thunder",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "anxiety (interacts with) thunder",
        "interaction" : "interacts with",
        "SUID" : 536,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "530",
        "source" : "410",
        "target" : "527",
        "EdgeBetweenness" : 44.69209540965584,
        "shared_name" : "anxiety (interacts with) raining",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "anxiety (interacts with) raining",
        "interaction" : "interacts with",
        "SUID" : 530,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "524",
        "source" : "410",
        "target" : "521",
        "EdgeBetweenness" : 44.69209540965584,
        "shared_name" : "anxiety (interacts with) frightening",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "anxiety (interacts with) frightening",
        "interaction" : "interacts with",
        "SUID" : 524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "518",
        "source" : "410",
        "target" : "515",
        "EdgeBetweenness" : 44.692095409655835,
        "shared_name" : "anxiety (interacts with) grey sky",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "anxiety (interacts with) grey sky",
        "interaction" : "interacts with",
        "SUID" : 518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "512",
        "source" : "410",
        "target" : "509",
        "EdgeBetweenness" : 44.692095409655835,
        "shared_name" : "anxiety (interacts with) clouds",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "anxiety (interacts with) clouds",
        "interaction" : "interacts with",
        "SUID" : 512,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "506",
        "source" : "410",
        "target" : "503",
        "EdgeBetweenness" : 44.692095409655835,
        "shared_name" : "anxiety (interacts with) air",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Virga",
        "name" : "anxiety (interacts with) air",
        "interaction" : "interacts with",
        "SUID" : 506,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "500",
        "source" : "410",
        "target" : "497",
        "EdgeBetweenness" : 36.0143400436881,
        "shared_name" : "anxiety (interacts with) Witnessed.",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "anxiety (interacts with) Witnessed.",
        "interaction" : "interacts with",
        "SUID" : 500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "494",
        "source" : "410",
        "target" : "491",
        "EdgeBetweenness" : 36.01434004368805,
        "shared_name" : "anxiety (interacts with) Never",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "anxiety (interacts with) Never",
        "interaction" : "interacts with",
        "SUID" : 494,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "488",
        "source" : "410",
        "target" : "485",
        "EdgeBetweenness" : 36.01434004368805,
        "shared_name" : "anxiety (interacts with) They see it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "anxiety (interacts with) They see it",
        "interaction" : "interacts with",
        "SUID" : 488,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "482",
        "source" : "410",
        "target" : "479",
        "EdgeBetweenness" : 36.01434004368806,
        "shared_name" : "anxiety (interacts with) No escaping",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "anxiety (interacts with) No escaping",
        "interaction" : "interacts with",
        "SUID" : 482,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "476",
        "source" : "410",
        "target" : "473",
        "EdgeBetweenness" : 36.014340043688065,
        "shared_name" : "anxiety (interacts with) Relentlessly)",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "anxiety (interacts with) Relentlessly)",
        "interaction" : "interacts with",
        "SUID" : 476,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "470",
        "source" : "410",
        "target" : "467",
        "EdgeBetweenness" : 36.01434004368807,
        "shared_name" : "anxiety (interacts with) Hunting",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "anxiety (interacts with) Hunting",
        "interaction" : "interacts with",
        "SUID" : 470,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "464",
        "source" : "410",
        "target" : "181",
        "EdgeBetweenness" : 222.18066112599448,
        "shared_name" : "anxiety (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "anxiety (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "461",
        "source" : "410",
        "target" : "458",
        "EdgeBetweenness" : 36.01434004368808,
        "shared_name" : "anxiety (interacts with) The eyes",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "anxiety (interacts with) The eyes",
        "interaction" : "interacts with",
        "SUID" : 461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "source" : "410",
        "target" : "452",
        "EdgeBetweenness" : 36.01434004368808,
        "shared_name" : "anxiety (interacts with) Always watching",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Witness",
        "name" : "anxiety (interacts with) Always watching",
        "interaction" : "interacts with",
        "SUID" : 455,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "449",
        "source" : "410",
        "target" : "446",
        "EdgeBetweenness" : 40.699473085116196,
        "shared_name" : "anxiety (interacts with) I can feel it",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "anxiety (interacts with) I can feel it",
        "interaction" : "interacts with",
        "SUID" : 449,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "source" : "410",
        "target" : "440",
        "EdgeBetweenness" : 40.699473085116196,
        "shared_name" : "anxiety (interacts with) gaps of my teeth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "anxiety (interacts with) gaps of my teeth",
        "interaction" : "interacts with",
        "SUID" : 443,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "437",
        "source" : "410",
        "target" : "434",
        "EdgeBetweenness" : 40.699473085116196,
        "shared_name" : "anxiety (interacts with) poke out my nostrils",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "anxiety (interacts with) poke out my nostrils",
        "interaction" : "interacts with",
        "SUID" : 437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "source" : "410",
        "target" : "428",
        "EdgeBetweenness" : 40.699473085116196,
        "shared_name" : "anxiety (interacts with) pushes at my nerves",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "anxiety (interacts with) pushes at my nerves",
        "interaction" : "interacts with",
        "SUID" : 431,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "source" : "410",
        "target" : "422",
        "EdgeBetweenness" : 40.699473085116196,
        "shared_name" : "anxiety (interacts with) too big for my body",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "anxiety (interacts with) too big for my body",
        "interaction" : "interacts with",
        "SUID" : 425,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "419",
        "source" : "410",
        "target" : "416",
        "EdgeBetweenness" : 118.42360253533172,
        "shared_name" : "anxiety (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "anxiety (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 419,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "source" : "410",
        "target" : "181",
        "EdgeBetweenness" : 222.18066112599448,
        "shared_name" : "anxiety (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Host",
        "name" : "anxiety (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 413,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "407",
        "source" : "362",
        "target" : "404",
        "EdgeBetweenness" : 14.496111431395454,
        "shared_name" : "anorexia (interacts with) wrongness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "anorexia (interacts with) wrongness",
        "interaction" : "interacts with",
        "SUID" : 407,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "source" : "362",
        "target" : "278",
        "EdgeBetweenness" : 24.65794126754637,
        "shared_name" : "anorexia (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "anorexia (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 401,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "source" : "362",
        "target" : "395",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "anorexia (interacts with) pallidity",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "anorexia (interacts with) pallidity",
        "interaction" : "interacts with",
        "SUID" : 398,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "392",
        "source" : "362",
        "target" : "389",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "anorexia (interacts with) withering",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "anorexia (interacts with) withering",
        "interaction" : "interacts with",
        "SUID" : 392,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "386",
        "source" : "362",
        "target" : "233",
        "EdgeBetweenness" : 62.50906386930152,
        "shared_name" : "anorexia (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "anorexia (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 386,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "383",
        "source" : "362",
        "target" : "380",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "anorexia (interacts with) vacancy",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "anorexia (interacts with) vacancy",
        "interaction" : "interacts with",
        "SUID" : 383,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "source" : "362",
        "target" : "374",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "anorexia (interacts with) void",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "anorexia (interacts with) void",
        "interaction" : "interacts with",
        "SUID" : 377,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "source" : "362",
        "target" : "368",
        "EdgeBetweenness" : 14.49611143139545,
        "shared_name" : "anorexia (interacts with) hollow",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "anorexia (interacts with) hollow",
        "interaction" : "interacts with",
        "SUID" : 371,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "source" : "362",
        "target" : "181",
        "EdgeBetweenness" : 95.00774225299043,
        "shared_name" : "anorexia (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Hollow",
        "name" : "anorexia (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 365,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "source" : "335",
        "target" : "245",
        "EdgeBetweenness" : 14.50920783122584,
        "shared_name" : "anger (interacts with) copper",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "anger (interacts with) copper",
        "interaction" : "interacts with",
        "SUID" : 359,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "source" : "335",
        "target" : "239",
        "EdgeBetweenness" : 14.50920783122584,
        "shared_name" : "anger (interacts with) blowtorch",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "anger (interacts with) blowtorch",
        "interaction" : "interacts with",
        "SUID" : 356,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "353",
        "source" : "335",
        "target" : "233",
        "EdgeBetweenness" : 62.935338530319584,
        "shared_name" : "anger (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "anger (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "350",
        "source" : "335",
        "target" : "227",
        "EdgeBetweenness" : 14.509207831225838,
        "shared_name" : "anger (interacts with) pay",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "anger (interacts with) pay",
        "interaction" : "interacts with",
        "SUID" : 350,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "source" : "335",
        "target" : "221",
        "EdgeBetweenness" : 14.50920783122584,
        "shared_name" : "anger (interacts with) thing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "anger (interacts with) thing",
        "interaction" : "interacts with",
        "SUID" : 347,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "344",
        "source" : "335",
        "target" : "215",
        "EdgeBetweenness" : 14.509207831225838,
        "shared_name" : "anger (interacts with) searing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "anger (interacts with) searing",
        "interaction" : "interacts with",
        "SUID" : 344,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "341",
        "source" : "335",
        "target" : "209",
        "EdgeBetweenness" : 8.612562181007252,
        "shared_name" : "anger (interacts with) redness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "anger (interacts with) redness",
        "interaction" : "interacts with",
        "SUID" : 341,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "source" : "335",
        "target" : "181",
        "EdgeBetweenness" : 93.6089307753684,
        "shared_name" : "anger (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "anger (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "950",
        "source" : "304",
        "target" : "416",
        "EdgeBetweenness" : 16.4004329004329,
        "shared_name" : "heartbeat (interacts with) beat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "heartbeat (interacts with) beat",
        "interaction" : "interacts with",
        "SUID" : 950,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "947",
        "source" : "304",
        "target" : "662",
        "EdgeBetweenness" : 44.4004329004329,
        "shared_name" : "heartbeat (interacts with) Heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "heartbeat (interacts with) Heartbeat",
        "interaction" : "interacts with",
        "SUID" : 947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "944",
        "source" : "304",
        "target" : "304",
        "EdgeBetweenness" : 0.0,
        "shared_name" : "heartbeat (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Pulse",
        "name" : "heartbeat (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 944,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "source" : "302",
        "target" : "181",
        "EdgeBetweenness" : 85.62491836799354,
        "shared_name" : "aging (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "aging (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "329",
        "source" : "302",
        "target" : "326",
        "EdgeBetweenness" : 24.177509776505453,
        "shared_name" : "aging (interacts with) alight in tremors",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "aging (interacts with) alight in tremors",
        "interaction" : "interacts with",
        "SUID" : 329,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "323",
        "source" : "302",
        "target" : "320",
        "EdgeBetweenness" : 24.177509776505456,
        "shared_name" : "aging (interacts with) greying stains",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "aging (interacts with) greying stains",
        "interaction" : "interacts with",
        "SUID" : 323,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "317",
        "source" : "302",
        "target" : "314",
        "EdgeBetweenness" : 24.177509776505453,
        "shared_name" : "aging (interacts with) spiraling grain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "aging (interacts with) spiraling grain",
        "interaction" : "interacts with",
        "SUID" : 317,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "311",
        "source" : "302",
        "target" : "233",
        "EdgeBetweenness" : 69.73746359852503,
        "shared_name" : "aging (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "aging (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 311,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "source" : "302",
        "target" : "304",
        "EdgeBetweenness" : 46.56848100581414,
        "shared_name" : "aging (interacts with) heartbeat",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Clockface",
        "name" : "aging (interacts with) heartbeat",
        "interaction" : "interacts with",
        "SUID" : 308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1433",
        "source" : "254",
        "target" : "296",
        "EdgeBetweenness" : 6.4822758251549155,
        "shared_name" : "mold (interacts with) germs",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "mold (interacts with) germs",
        "interaction" : "interacts with",
        "SUID" : 1433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1430",
        "source" : "254",
        "target" : "290",
        "EdgeBetweenness" : 6.482275825154915,
        "shared_name" : "mold (interacts with) slap",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "mold (interacts with) slap",
        "interaction" : "interacts with",
        "SUID" : 1430,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1427",
        "source" : "254",
        "target" : "284",
        "EdgeBetweenness" : 6.482275825154913,
        "shared_name" : "mold (interacts with) growth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "mold (interacts with) growth",
        "interaction" : "interacts with",
        "SUID" : 1427,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1424",
        "source" : "254",
        "target" : "278",
        "EdgeBetweenness" : 14.246498306149409,
        "shared_name" : "mold (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "mold (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 1424,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1421",
        "source" : "254",
        "target" : "272",
        "EdgeBetweenness" : 6.482275825154912,
        "shared_name" : "mold (interacts with) fuzzing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "mold (interacts with) fuzzing",
        "interaction" : "interacts with",
        "SUID" : 1421,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1418",
        "source" : "254",
        "target" : "266",
        "EdgeBetweenness" : 6.482275825154911,
        "shared_name" : "mold (interacts with) spores",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "mold (interacts with) spores",
        "interaction" : "interacts with",
        "SUID" : 1418,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1415",
        "source" : "254",
        "target" : "260",
        "EdgeBetweenness" : 6.482275825154911,
        "shared_name" : "mold (interacts with) rot",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "mold (interacts with) rot",
        "interaction" : "interacts with",
        "SUID" : 1415,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1412",
        "source" : "254",
        "target" : "254",
        "EdgeBetweenness" : 0.0,
        "shared_name" : "mold (interacts with) mold",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "mold (interacts with) mold",
        "interaction" : "interacts with",
        "SUID" : 1412,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1409",
        "source" : "254",
        "target" : "233",
        "EdgeBetweenness" : 83.71052844940934,
        "shared_name" : "mold (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "mold (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1409,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1613",
        "source" : "209",
        "target" : "245",
        "EdgeBetweenness" : 7.896645650218585,
        "shared_name" : "redness (interacts with) copper",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "redness (interacts with) copper",
        "interaction" : "interacts with",
        "SUID" : 1613,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1610",
        "source" : "209",
        "target" : "239",
        "EdgeBetweenness" : 7.896645650218585,
        "shared_name" : "redness (interacts with) blowtorch",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "redness (interacts with) blowtorch",
        "interaction" : "interacts with",
        "SUID" : 1610,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1607",
        "source" : "209",
        "target" : "233",
        "EdgeBetweenness" : 42.281086174369776,
        "shared_name" : "redness (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "redness (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 1607,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1604",
        "source" : "209",
        "target" : "227",
        "EdgeBetweenness" : 7.896645650218586,
        "shared_name" : "redness (interacts with) pay",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "redness (interacts with) pay",
        "interaction" : "interacts with",
        "SUID" : 1604,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1601",
        "source" : "209",
        "target" : "221",
        "EdgeBetweenness" : 7.896645650218585,
        "shared_name" : "redness (interacts with) thing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "redness (interacts with) thing",
        "interaction" : "interacts with",
        "SUID" : 1601,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1598",
        "source" : "209",
        "target" : "215",
        "EdgeBetweenness" : 7.896645650218585,
        "shared_name" : "redness (interacts with) searing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "redness (interacts with) searing",
        "interaction" : "interacts with",
        "SUID" : 1598,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1595",
        "source" : "209",
        "target" : "209",
        "EdgeBetweenness" : 0.0,
        "shared_name" : "redness (interacts with) redness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "redness (interacts with) redness",
        "interaction" : "interacts with",
        "SUID" : 1595,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1592",
        "source" : "209",
        "target" : "181",
        "EdgeBetweenness" : 68.33855621736171,
        "shared_name" : "redness (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "redness (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 1592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "299",
        "source" : "179",
        "target" : "296",
        "EdgeBetweenness" : 18.606658678704374,
        "shared_name" : "abuse (interacts with) germs",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "abuse (interacts with) germs",
        "interaction" : "interacts with",
        "SUID" : 299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "293",
        "source" : "179",
        "target" : "290",
        "EdgeBetweenness" : 18.60665867870437,
        "shared_name" : "abuse (interacts with) slap",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "abuse (interacts with) slap",
        "interaction" : "interacts with",
        "SUID" : 293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "287",
        "source" : "179",
        "target" : "284",
        "EdgeBetweenness" : 18.60665867870437,
        "shared_name" : "abuse (interacts with) growth",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "abuse (interacts with) growth",
        "interaction" : "interacts with",
        "SUID" : 287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "source" : "179",
        "target" : "278",
        "EdgeBetweenness" : 25.941152857280784,
        "shared_name" : "abuse (interacts with) blood",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "abuse (interacts with) blood",
        "interaction" : "interacts with",
        "SUID" : 281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "source" : "179",
        "target" : "272",
        "EdgeBetweenness" : 18.606658678704367,
        "shared_name" : "abuse (interacts with) fuzzing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "abuse (interacts with) fuzzing",
        "interaction" : "interacts with",
        "SUID" : 275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "269",
        "source" : "179",
        "target" : "266",
        "EdgeBetweenness" : 18.606658678704363,
        "shared_name" : "abuse (interacts with) spores",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "abuse (interacts with) spores",
        "interaction" : "interacts with",
        "SUID" : 269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "263",
        "source" : "179",
        "target" : "260",
        "EdgeBetweenness" : 18.606658678704363,
        "shared_name" : "abuse (interacts with) rot",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "abuse (interacts with) rot",
        "interaction" : "interacts with",
        "SUID" : 263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "source" : "179",
        "target" : "254",
        "EdgeBetweenness" : 9.628031527151219,
        "shared_name" : "abuse (interacts with) mold",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "abuse (interacts with) mold",
        "interaction" : "interacts with",
        "SUID" : 257,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "251",
        "source" : "179",
        "target" : "233",
        "EdgeBetweenness" : 63.17203746420197,
        "shared_name" : "abuse (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Rotten",
        "name" : "abuse (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "source" : "179",
        "target" : "245",
        "EdgeBetweenness" : 18.134625009875624,
        "shared_name" : "abuse (interacts with) copper",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "abuse (interacts with) copper",
        "interaction" : "interacts with",
        "SUID" : 248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "source" : "179",
        "target" : "239",
        "EdgeBetweenness" : 18.134625009875624,
        "shared_name" : "abuse (interacts with) blowtorch",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "abuse (interacts with) blowtorch",
        "interaction" : "interacts with",
        "SUID" : 242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "source" : "179",
        "target" : "233",
        "EdgeBetweenness" : 63.17203746420197,
        "shared_name" : "abuse (interacts with) pain",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "abuse (interacts with) pain",
        "interaction" : "interacts with",
        "SUID" : 236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "source" : "179",
        "target" : "227",
        "EdgeBetweenness" : 18.134625009875627,
        "shared_name" : "abuse (interacts with) pay",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "abuse (interacts with) pay",
        "interaction" : "interacts with",
        "SUID" : 230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "224",
        "source" : "179",
        "target" : "221",
        "EdgeBetweenness" : 18.134625009875627,
        "shared_name" : "abuse (interacts with) thing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "abuse (interacts with) thing",
        "interaction" : "interacts with",
        "SUID" : 224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "218",
        "source" : "179",
        "target" : "215",
        "EdgeBetweenness" : 18.134625009875627,
        "shared_name" : "abuse (interacts with) searing",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "abuse (interacts with) searing",
        "interaction" : "interacts with",
        "SUID" : 218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "212",
        "source" : "179",
        "target" : "209",
        "EdgeBetweenness" : 10.921874238465197,
        "shared_name" : "abuse (interacts with) redness",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "abuse (interacts with) redness",
        "interaction" : "interacts with",
        "SUID" : 212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "source" : "179",
        "target" : "181",
        "EdgeBetweenness" : 107.96004804447035,
        "shared_name" : "abuse (interacts with) me",
        "shared_interaction" : "interacts with",
        "Poem_Title" : "Red",
        "name" : "abuse (interacts with) me",
        "interaction" : "interacts with",
        "SUID" : 202,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}