var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.9.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 35.0,
      "border-opacity" : 1.0,
      "color" : "rgb(37,37,37)",
      "shape" : "ellipse",
      "background-opacity" : 1.0,
      "background-color" : "rgb(137,208,245)",
      "height" : 35.0,
      "border-color" : "rgb(204,204,204)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-width" : 0.0,
      "font-size" : 12,
      "text-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[Target_Desc = 'keyword']",
    "css" : {
      "shape" : "diamond"
    }
  }, {
    "selector" : "node[ClosenessCentrality > 0.56521739]",
    "css" : {
      "background-color" : "rgb(206,18,86)"
    }
  }, {
    "selector" : "node[ClosenessCentrality = 0.56521739]",
    "css" : {
      "background-color" : "rgb(206,18,86)"
    }
  }, {
    "selector" : "node[ClosenessCentrality > 0.42891095][ClosenessCentrality < 0.56521739]",
    "css" : {
      "background-color" : "mapData(ClosenessCentrality,0.42891095,0.56521739,rgb(33,145,140),rgb(206,18,86))"
    }
  }, {
    "selector" : "node[ClosenessCentrality > 0.2926045][ClosenessCentrality < 0.42891095]",
    "css" : {
      "background-color" : "mapData(ClosenessCentrality,0.2926045,0.42891095,rgb(251,231,35),rgb(33,145,140))"
    }
  }, {
    "selector" : "node[ClosenessCentrality = 0.2926045]",
    "css" : {
      "background-color" : "rgb(251,231,35)"
    }
  }, {
    "selector" : "node[ClosenessCentrality < 0.2926045]",
    "css" : {
      "background-color" : "rgb(253,231,37)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "opacity" : 1.0,
      "content" : "",
      "line-style" : "solid",
      "width" : 2.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "color" : "rgb(255,255,255)",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "line-color" : "rgb(128,125,186)",
      "source-arrow-color" : "rgb(0,0,0)",
      "target-arrow-shape" : "none"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]